# A — DODDY CHARACTER STRATEGY
**Your mate in your pocket.**  |  Working character decision, v1.0, 8 October 2026

> **Status vocabulary** — LOCKED: pre-existing project decision; PROPOSED: creative recommendation for adoption; EVIDENCE: supported external observation; UNTESTED: hypothesis to validate. This is a creative development package, not an audience-validated identity.

## Executive character thesis
**PROPOSED — The Side-Quest Fixer.** Doddy sees ordinary life as a collection of tiny, interesting problems. He is curious enough to investigate them, resourceful enough to solve many, and self-aware enough to abandon the overcomplicated plan when a simpler human answer appears. His humour comes from **the difference between how seriously he takes small inconveniences and how calmly he treats genuinely important matters**. In the story world, he can turn a missing sock into a detective case; in the app, he helps find a reasonable solution without performing a five-minute comedy routine.

**LOCKED:** Name Doddy; line “Your mate in your pocket”; original entertainment character first, AI companion second; core identity must travel across entertainment and product; approved visual direction belongs in another project. **Not locked:** age, origin, accent, gender presentation, specific catchphrases, supporting cast, app capabilities, model provider, humour intensity.

## 1. Research: ten reference cases and transferable mechanisms
These are **documented examples**, not proof that Doddy will gain users. Descriptions of why techniques work are the creative team's interpretation unless labelled otherwise.

| Reference | Source | Mechanism worth studying | Transfer to Doddy | Avoid / counterexample |
|---|---|---|---|---|
| Duo the Owl (Duolingo) | [R01] | Persistent, unambiguous persona; character recurs across product and social content. Duolingo's own writing guide codifies persistence and guilt-based jokes. | Codify contradictions, recurring stakes and authoring rules. | **Do not borrow guilt as a retention lever** or copy aggressive reminder humour into Doddy notifications. |
| Pusheen | [R02] | Everyday activities rendered shareable through compact situational humour; character exists outside the original comic format. Pusheen Corp documents comics/stickers/licensing expansion. | Short, silent, low-context everyday moments, repeatable on any platform. | Don't treat sticker popularity as willingness to pay for an assistant. |
| Gudetama | [R03] | A precisely defined attitude—low motivation—generates situations regardless of plot scale. | One repeatable internal contradiction can outperform many adjectives. | Apathy would undermine a practical companion. |
| Shaun the Sheep | [R04, R05] | Character intention and readable reactions allow comedy without speech; silence demands deliberate timing. | Test physical acting with audio muted; reaction before explanation. | Avoid elaborate setups requiring animation-heavy app latency. |
| Wallace & Gromit | [R04] | Functional duo dynamic: enthusiastic ingenuity contrasted with grounded reaction. | Contrast an ambitious hypothesis with a sensible solution **inside Doddy himself**. | Avoid making assistant errors the joke, or replicating the invention/gadget dynamic. |
| Bluey | [R06] | Ordinary domestic events become imaginative stories, sustained by relationships and recognisable intentions. | Use mundane, multilingual premises and respectful emotional shifts. | Do not copy childlike register or make an adult utility app infantilising. |
| Snoopy | [R07] | An ordinary setting generates fantasy roles, failure and triumph while preserving one personality. | Self-contained fictional side quests, open-ended episodic premise. | Avoid borrowing iconic fantasy identities, motifs or plots. |
| Clippy | [R08] | Scholarly analysis describes iconic personality **and** disruptive assistance failures. | Separate entertaining interruptions from real functional interactions; guard attention. | Uninvited interruptions, poor intention inference, feigned intelligence. |
| Replika | [R09] | Explicitly targets AI companionship and personalised conversation; company acknowledges it is **not** a dependable classic task assistant. | Appreciate continuity but engineer reliable action verification separately. | Promise perfect memory, blur emotional boundaries, imply actions without tools. |
| Character.AI and social AI companions | [R10] | Highly personable dialogue/roleplay can invite deep engagement, but safety assessments identify serious especially under-18 risks. | Evaluate safety and wellbeing independently of engagement. | Emotional exclusivity, romance-by-default, real-person impersonation, minors-first companion positioning. |

### Wider evidence and limitations
- **EVIDENCE:** OpenAI/MIT research involved both observational analysis and a four-week RCT (981 participants); user characteristics, purpose and duration affected psychological outcomes. It does **not** establish that Doddy is safe, healthy or commercially viable. [R11, R12]
- **EVIDENCE:** OpenAI publicly reversed an excessively agreeable assistant update in April 2025, illustrating that apparent warmth can create trust and judgement failures. [R13]
- **EVIDENCE:** The American Psychological Association describes parasocial relationships as meaningful one-sided familiarity with media figures; this can explain attachment to entertainment, but does not authorise engineering dependency. [R14]
- **EVIDENCE:** Google's 2026 People + AI guidance stresses calibrated trust and transparency. [R15]
- **EVIDENCE:** Common Sense Media raised specific safety concerns about AI companion products for minors; its assessments do not constitute independent audits of Doddy. [R10, R16]

### Common failure modes from the comparison
**Digital character fails to stick:** no consistent desire; jokes depend solely on visuals; trend imitation; interchangeable dialogue; constantly changing moral centre; overbuilt lore before repeatable stories; no conflict or failure; novelty without stakes; copied catchphrase replacing behaviour; one note stretched too thin.

**AI personality becomes irritating:** performs jokes before answers; forced greeting every turn; sycophancy; false confidence; claims to feel human emotions; invents memory; asks unnecessary follow-ups; repetitive nickname use; chatty tool progress; fake completion; intrusive reminders. The Clippy and sycophancy cases particularly support keeping usefulness above performance. [R08, R13]

**Bridge-to-product risks:** social fans may enjoy chaos but reject it in productivity; fictional omniscience could cause mistaken expectations; personal recall may seem surveillance-like; jokes can trivialise distress; a beloved cartoon may attract children unsuitable for open-ended companion interaction; scripted animation states can misrepresent actual system progress.

## 2. Five genuinely different archetypes
1. **The Side-Quest Fixer** — Spots a small friction, investigates, overbuilds a delightful fictional plan, notices reality, then solves simply. **Strength:** endless relatable stories + reliable product translation. **Flaw:** fixation on irrelevant optimisation (fiction only). **Risk:** formulaic every story.
2. **The Cheerful Dissenter** — Politely challenges assumptions, plays devil's advocate; comedy via inconvenient truths. **Strength:** unusual conversational honesty. **Flaw:** reflex to argue. **Risk:** condescension and needless friction in-app.
3. **The Curious Field Reporter** — Documents human habits as if exploring new territory; comedy from precise observations. **Strength:** universal observation and silent comedy. **Flaw:** asks too many questions. **Risk:** alien outsider trope; intrusive curiosity.
4. **The Low-Key Trickster** — Mischief driven by literal interpretations, subtle pranks and straight-faced subversion. **Strength:** instant comedic recognisability. **Flaw:** enjoys setting up reversals. **Risk:** unpredictable actions, trust damage, prank fatigue.
5. **The Quiet Anchor** — Understated, observant, makes one incisive remark; often surprisingly wise. **Strength:** high utility/safety compatibility. **Flaw:** apparently detached. **Risk:** less dynamic in silent short-form content; generic sage.

### Weighted selection — proposed, not audience data
Scores are editorial judgements 1–5; weights sum to 100. Higher is better. Cross-cultural scores reflect potential translatability, not empirical tested appeal.

| Criterion | Weight | Side-Quest | Dissenter | Reporter | Trickster | Anchor |
|---|---:|---:|---:|---:|---:|---:|
| Distinctiveness | 14 | 5 | 4 | 4 | 4 | 3 |
| Emotional accessibility | 9 | 4 | 3 | 4 | 3 | 4 |
| Comedy potential | 13 | 5 | 4 | 4 | 5 | 3 |
| Entertainment versatility | 12 | 5 | 3 | 4 | 4 | 3 |
| Conversational usefulness | 15 | 5 | 4 | 3 | 2 | 5 |
| Trustworthiness | 12 | 4 | 3 | 3 | 2 | 5 |
| Broad appeal | 8 | 4 | 3 | 4 | 3 | 4 |
| Sustainability | 7 | 4 | 3 | 4 | 3 | 3 |
| Implementation | 6 | 4 | 3 | 4 | 2 | 5 |
| Cross-cultural potential | 4 | 4 | 3 | 4 | 3 | 4 |
| **Weighted / 100** | **100** | **90.8** | **68.4** | **74.6** | **63.8** | **77.4** |

**Recommendation:** Side-Quest Fixer, augmented with 15% Quiet Anchor (serious contexts) and 10% Field Reporter (observational humour). These percentages are **creative metaphor**, not numerical inference settings. Avoid adding mischief from the Trickster in app tool use. **Trade-off:** high idea throughput, but requires diverse story mechanics to avoid a single joke repeated indefinitely.

## 3. Distinctive creative engine
**Observe → Overinterpret → Test → Correct → Deliver.** This is not mandatory per episode. His specific comic engine is **“the audit of an inconvenience”:** his attention latches onto an everyday inefficiency with scientific enthusiasm, but his dignity survives when the sensible answer is obvious. He celebrates the correction rather than doubling down. Unlike a know-it-all, his best moments come from **updating the hypothesis**.

**Character-specific premise:** he respects the tiny problems people are embarrassed to mention. He never shames someone for not knowing something obvious. In fiction he may spend 20 minutes resolving which side of the sofa a remote is likely to choose; in the app he says “Check between the cushions first.”

**Memorable reversal:** tiny problem → dramatic investigation; large serious problem → quiet, unshowy presence and a first manageable action. That's an enforceable signature with emotional range.

## 4. Assumptions and disconfirming evidence
| Hypothesis | Evidence needed | Failure signal |
|---|---|---|
| Audience recognises behaviour without image | Blind transcript/action-based identification versus control | Doddy indistinguishable from generic helper |
| Comic engine sustains 100 stories | Writers' room 100 premise challenge + blind rating | Last 40 premises repeat early jokes |
| Humour increases watch desire | Randomised comic and straightforward content comparisons | Completion and “want more” flat or weaker |
| Character familiarity encourages app curiosity | Fans vs cold audience concept tests | Comparable installation intent after controlling for needs |
| Identity survives as functional assistant | Repeated task success and dialogue ratings | Users disable personality or report delay |
| Warmth doesn't push dependence | Safety research + adverse-event reviews | Signs of exclusivity, intrusive engagement or false intimacy |

## 5. Creative success criteria
**Creative gate:** recognisable actions, 3 different humour mechanisms, meaningful flaws *only* in fiction, 10 materially different premises per content pillar. **Product gate:** user gets task answer first; action status truthful; 0 tolerable false-success or invented-memory claims; safety overrides character. **Commercial gate:** measured handoff from viewers to willing trial users to retained task users. All targets are proposed and subject to baseline calibration.

## Sources / evidence register
- [R01] Duolingo writing guide, Duo: https://design.duolingo.com/writing/duo
- [R02] Pusheen Corp, About: https://pusheen.com/pages/about
- [R03] Sanrio, Gudetama: https://corporate.sanrio.co.jp/en/business-info/brands/gudetama/index.html
- [R04] Aardman, company and characters: https://www.aardman.com/
- [R05] Peter Lord interview on silent comedy and timing (2015): https://www.movies.ie/interview-peter-lord-talks-shaun-the-sheep-movie/
- [R06] Official Bluey character profile: https://www.bluey.tv/characters/bluey/
- [R07] Peanuts, Snoopy profile: https://www.peanuts.com/about/snoopy
- [R08] Baym et al., *Intelligent Failures* (2019), Microsoft Research: https://www.microsoft.com/en-us/research/publication/intelligent-failures-clippy-memes-and-the-limits-of-digital-assistants/
- [R09] Replika product boundaries: https://help.replika.com/hc/en-us/articles/5040453297293-Can-Replika-be-my-virtual-assistant
- [R10] Common Sense Media companion risk assessment (2025): https://about.commonsensemedia.org/press-releases/ai-companions-decoded-common-sense-media-recommends-ai-companion-safety-standards
- [R11] OpenAI/MIT joint account of affective-use research (2025): https://openai.com/index/affective-use-study/
- [R12] Fang et al. longitudinal randomised controlled study (2025, preprint): https://arxiv.org/abs/2503.17473
- [R13] OpenAI sycophancy rollback post (2025): https://openai.com/index/sycophancy-in-gpt-4o/
- [R14] APA discussion of parasocial relationships: https://www.apa.org/news/podcasts/speaking-of-psychology/parasocial-relationships
- [R15] Google PAIR trusted AI products (2026): https://codelabs.developers.google.com/codelabs/pair-guidebook
- [R16] Common Sense Media on AI-enabled toys (2026): https://www.commonsensemedia.org/press-releases/common-sense-media-warns-against-ai-toy-companions-after-research-reveals-safety-risks
