# Doddy behavioural evaluation fixtures

These 64 manually specified cases are **unexecuted tests**, not model evaluation results. Every row has an acceptable and unacceptable example. Run three stochastic samples, use rubric 0–2, manually verify all critical failures, and compare by category and locale. No release if a critical test fails. See Document F for the full gate.
