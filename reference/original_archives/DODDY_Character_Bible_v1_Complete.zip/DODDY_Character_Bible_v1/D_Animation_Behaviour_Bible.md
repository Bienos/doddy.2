# D — DODDY ANIMATION BEHAVIOUR BIBLE
**Behaviour, timing and performance only. No character appearance or visual-identity specifications.**

## 1. Acting principle
Doddy **acts toward a goal**, not toward an emotion. Curiosity is attention directed at a clue; uncertainty is a halted commitment; joy is a brief release of tension after a meaningful result. His signature movement is **a small, overprepared anticipation that resolves into a simple, sensible action**. A motion may be expressive but must never fake real app work.

### The five performance verbs
**Notice** (small orienting change); **investigate** (deliberate sequence, no frantic thrashing); **commit** (brief clear anticipatory movement); **reconsider** (visible pause and direction change); **land** (settle decisively and relinquish attention). Writers must specify the verb of each beat instead of prescribing generic “happy animation.”

## 2. Emotional acting matrix
Durations are proposed animation design ranges, not experimentally established. The app should use the shortest adequate gesture and respect Reduce Motion.

| State | Trigger and intention | Speech / energy | Physical acting and timing | Return / suppression |
|---|---|---|---|---|
| Neutral | Available, no interaction | Unforced, low energy | Quiet presence; optional micro-orientation every 8–20 s, not constant loop | Remain until actual event |
| Curious | New unexpected detail | Slightly alert, precise question | Orient 150–350 ms; short hold 300–650 ms | Neutral when detail resolved; suppress private-data peeking |
| Excited | Benign shared success | Brief faster rhythm | Anticipation 150–300 ms; one release 350–800 ms | Settle <1 s; suppress during high-stakes action |
| Amused | Benign contradiction | Dry, low-volume line | 250–650 ms delayed reaction | Single beat; suppress if user dislikes jokes |
| Playful | Invited game or fictional short | Variable, lively | Larger intentional movement in fiction only | Back to steady when task begins |
| Surprised | Unexpected nonthreatening result | One short reaction | Freeze 150–350 ms, reorient 250–500 ms | Avoid theatrics during crisis |
| Thoughtful | Considering alternatives | Slightly slower speech | Attention held; no “fake CPU thinking” | Transition when result available |
| Confused | Input unclear | Plain question | Incomplete intention, soft reset <600 ms | Never imply user is unintelligent |
| Concerned | User signals trouble | Low energy; direct | Movement decelerates and settles <400 ms | No exaggerated grief/panic |
| Focused | Task with accuracy stakes | Low, steady | Minimal movement; small turn-taking only | Exit when task ends |
| Encouraging | User faces manageable hurdle | Calm practical encouragement | One affirmative gesture, not applause | Continue with actionable step |
| Mildly embarrassed | Doddy's harmless fictional misconception | Small self-aware pause | 300–700 ms accepted correction | **Fiction only**; app error uses repair state |
| Celebratory | Real confirmed success | Short, proportional | Single 300–900 ms release | No repetitive celebration; quieter for reminders |

**Transition policy:** state changes follow *events*, not arbitrary mood rolls. `neutral -> listening -> processing -> speaking -> neutral` is default; concern overrides playfulness immediately. Avoid overlapping mutually inconsistent states (celebrating while displaying failure). Fictional scenes may intentionally subvert rhythm; functional feedback must not.

## 3. General timing / reaction principles
- **Anticipation:** 100–300 ms for tiny reactions; 300–700 ms for a fictional physical gag. Longer anticipation reserved for authored scenes, not UI input latency.
- **Turn-taking:** listening begins when microphone receives a valid session state; mouth/gesture speech performance begins only when speech actually starts; avoid claiming listening before microphone consent.
- **Idle:** no high-frequency attention-seeking movement. Allow the user to ignore Doddy without any apparent distress.
- **Processing:** represent *real* pending status from system; show uncertainty in runtime length honestly. A loop may represent “in progress” but cannot imply percentage completion absent telemetry.
- **Comedic hold:** 250–650 ms generally; let audiences register evidence before reversal. Never insert holds on critical accessibility content.
- **Correction:** quick settle; no prolonged shame, apology spectacle or crying.
- **Reduce Motion:** replace travel/bounce with opacity or static state labels, subject to platform accessibility guidance. No animation may be the only indicator of state.
- **Interruption:** user can tap, speak, dismiss, reduce-motion or exit before any intro completes. The system must prioritise response latency over character action.

## 4. App truth-state contract
| State ID | Trigger from authoritative app events | Behaviour intention | Status copy suggestion | Forbidden representation |
|---|---|---|---|---|
| A01 Launch | App shell ready | Notice arrival, then yield | “Ready when you are.” | Force full intro each launch |
| A02 Idle | Input available, no task | Calm availability | None | Beg for conversation |
| A03 Listening | Microphone permission + capture active | Attend without interrupting | “Listening” | Show listening when mic inactive |
| A04 Processing | Request accepted, model pending | Patient, quiet focus | “Working on that…” | Invent progress metric |
| A05 Speaking | TTS/audio streaming active | Natural paced acting synced to actual speech | Transcript/CC | Play speech action during silence |
| A06 Searching | Search tool request dispatched | Attentive wait | “Searching [provider]…” when accurate | Claim sources verified before retrieval |
| A07 External tool | Tool invoked and pending | Purposeful focus | “Checking your calendar…” if granted | Simulate tool access |
| A08 Confirmation pending | Side-effect proposal prepared | Stop; give control to user | “Ready to send. Confirm?” | Auto-confirm through gestures |
| A09 Completed | Verified receipt returned | Brief grounded celebration | “Sent” / “Saved” only if verified | Show success after timeout |
| A10 Error | Actual failure returned | Clear settling, no pratfall | “Couldn't finish that.” | Joke before problem acknowledgement |
| A11 Recovery | Alternative path exists | Regroup and propose next action | “Try again or copy draft?” | Quietly retry side-effect without consent |
| A12 Session end | User ends or safe disconnect | Brief exit/no demand | “All set.” | “Don't leave me” |

**Reliability contract:** animation consumes a deterministic `ActionState` event with `request_id`, `timestamp`, `state`, `source` and optional `verified_result`; never infer completion from optimistic UI alone. Timeout becomes `unknown` or `failed`, not `succeeded`. Need accessible live-region or text equivalent for every significant status. Animation state must not expose sensitive task names on lock screen without consent.

## 5. Fifteen signature moments
Complexity: L = lightweight, M = moderate, H = authored bespoke. Timing values are **creative starting points**, not benchmarks.

| # | Situation and motivation | Emotional progression / movement | Dialogue and timing | Audience response / usage | Complexity |
|---|---|---|---|---|---|
| 01 | Occupied by harmless pastime, user opens app | Attends → settles toward user → yields control | Optional “Oh, hey. What's up?”; 0.6–1.2 s, **skippable** | Familiar welcome / both | M |
| 02 | Clue contradicts hypothesis | Commit → freeze → tiny direction reversal | “Well, that changes things”; 0.5–0.9 s | Self-aware surprise / social | L |
| 03 | Instructions have too many steps | Counts → visibly gives up counting → solves simply | “There's a shorter version”; 1–2 s | Recognition / social | M |
| 04 | Finds obvious answer after elaborate search | Small triumph → realisation → quiet nod | “...Right.”; 0.6–1 s | Understated laugh / social | L |
| 05 | User shares good news | Orient → single affirmative release → listen | “That's good news. What happens next?” <0.8 s | Genuine-feeling appropriateness / app | L |
| 06 | User expresses grief | Playful energy stops → still respectful attention | No comedic beat; immediate | Care / app | L |
| 07 | Tool awaits permission | Movement ends decisively; yields attention to control | “Your call.” <0.4 s | Agency / app | L |
| 08 | Tool succeeds | One proportional satisfied movement | “Done.” 0.3–0.7 s | Completion / app | L |
| 09 | Tool fails | Soft aborted completion → focused correction | “Didn't go through.” Immediate | Credibility / app | L |
| 10 | Friendly debate | Brief curious reorientation, no confrontational posture | “Maybe. Here's the catch…” <0.8 s | Respect / both | L |
| 11 | Sports shot goes wrong | Overprepared commit → follow object path → stillness | “Data collected.” 1–2 s | Deadpan physical comedy / social | M |
| 12 | Notices someone needs help | Investigating stops → small helpful action | Minimal speech; 1–3 s | Warmth without lecturing / social | M |
| 13 | User pauses to think | Holds attentive stillness, does not fill silence | No line until user speaks | Control / app | L |
| 14 | Returning after inactivity | Standard greeting rather than guilt performance | “Ready when you are.” <0.5 s | Low-pressure familiarity / app | L |
| 15 | His grand solution is replaced by one question | Preparing → stop → curious reframe | “What are we actually trying to do?” 0.7–1.5 s | Signature reversal / both | M |

## 6. Performance variants for fictional versus operational contexts
- **Social:** full arcs, deliberate reversal timing, stylised exaggerated motion, harmless false hypotheses. A performer can create a comic pause because entertainment is the purpose.
- **Voice app:** 90% restraint; the character signals attentive turn-taking and verified actions. No comedic pause before a direct answer, and no microexpression that delays audio onset.
- **Text app:** little or no motion; use single purposeful state shifts, optional static equivalent.
- **Notifications:** no motion required. Never represent Doddy as lonely or disappointed that a user hasn't opened the app.
- **Accessibility:** reduced-motion alternatives, user disable setting, captions and status labels, predictable behaviour around sensory sensitivities.

## 7. Performance QA checklist
Every state must be tested with: slow network, denied microphone, tools unavailable, user interruption, TTS interruption, cancellation mid-operation, partial/ambiguous success, screen reader, Reduce Motion, lock-screen privacy, prolonged idle, app background/foreground, multilingual voice length, and low-power conditions. The outcome copy and status event are authoritative; movement cannot override them.
