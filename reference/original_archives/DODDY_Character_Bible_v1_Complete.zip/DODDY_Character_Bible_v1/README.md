# DODDY CHARACTER BIBLE — professional working package
**Edition:** v1.0, 8 October 2026  |  **Status:** Proposed for project-owner approval, not audience-validated.

## What you have
A coherent, research-informed entertainment-character and conversational-AI specification. No visual character design, illustrations, UI, storyboards or image-generation prompts are included.

### Documents (read in order)
- **A — Character Strategy:** 10 reference cases, evidence register, five archetypes and weighted decision matrix; risks and untested assumptions.
- **B — Definitive Character Bible:** essence, contradictions, 20 principles, 15 habits, 15 never-rules, 10 physical-only reactions, continuity and relationship boundaries.
- **C — Comedy & Content Bible:** humour matrix, 20 jokes, 10 situations, 10 bad jokes, 10 recovery lines, 10 useful comedic exchanges, 10 content pillars × five ideas, 10 formats, 20 concepts, 10 complete short scripts.
- **D — Animation Behaviour:** motion intentions, 13 emotional-expression states, truthful app states, timing recommendations and 15 signature moments. No appearance specifications.
- **E — Voice & Conversation:** natural English/Polish language rules, 15 bilingual examples, voice performance, sensitive and everyday conversations.
- **F — AI Personality Specification:** priority model, prompt, runtime, permissioned memory, proactive policy, tool-state contract, release/testing standards.
- **G — Validation & Governance:** 90-day plan, separate entertainment/product metrics, quality and anti-pattern controls, 15 critical-question audit.
- **H — Quick Reference:** operational one-page creative and product reminder.

### Engineering and research assets
- `engineering/doddy_persona_v1.yaml` — editable config schema and invariant rules (not production runtime code).
- `validation/behavioural_evals_64.csv` and `.jsonl` — 64 **unexecuted** test scenarios, each with context, acceptable/unacceptable examples, scoring criterion and critical flag.
- `validation/make_evals.py` — reproducible fixture authoring script.
- `validation/behavioural_evals_readme.md` — evaluation caveats.
- Research sources listed as direct URLs in Document A. They support analogy and risk assessment, **not** Doddy's business traction.

### How to use
1. Approve or amend proposed **Side-Quest Fixer** core direction and its non-negotiable ethical boundaries.
2. Let writers and performers run a 20-premise stress test. Revise canon after audience studies, not solely internal taste.
3. Use Document F/YAML to implement persona settings **only after** checking the existing app architecture. Enforce permissions and external tool effects outside the model.
4. Run all 64 fixtures with real model versions, capture failures, complete human bilingual and accessibility QA; no pass rates are claimed here.
5. Validate content appeal and app task value separately before spending on a launch.

### Critical limitations
Current GitHub repository contents were not inspected. No engineering feature, safety control, companion suitability for minors, legal compliance, production performance, benchmark result, user retention or commercial outcome is asserted. Proposed timing and success thresholds are starting hypotheses. This is character-development documentation and a candidate AI behaviour specification; it is not legal, psychiatric or platform-policy approval.
