# G — CHARACTER VALIDATION, GOVERNANCE & FINAL AUDIT
**Version 1.0 · All success thresholds below are proposed go/no-go heuristics, not proven industry benchmarks.**

## 1. The necessary separation
Treat **“I enjoy watching Doddy”**, **“I can recognise Doddy without his appearance”**, **“I want to talk to Doddy”**, **“Doddy helps me reliably”** and **“I will pay”** as five *independent* hypotheses. A viral animation establishes none of the latter four automatically. Recruitment channels and creative exposure must be controlled to avoid confusing character familiarity with task need.

## 2. Hypothesis register
| ID | Hypothesis | Minimum test | Disconfirming evidence |
|---|---|---|---|
| H1 | Blind recognition from behaviour exceeds generic character baseline | Text/audio-only match test | Chance-level identity selection |
| H2 | Comic premise works beyond one format | Three pillars × three mechanisms | Uniformly positive ratings only for one running gag |
| H3 | People request a second episode | A/B randomised short screening | “Cute once” dominates spontaneous comments |
| H4 | Spoken Doddy is perceived as natural | Blind dialogue comparison | Generic chatbot outperforms on naturalness |
| H5 | Doddy's humour does not delay tasks | Timed tasks with personality on/off | Higher time-to-answer or annoyance |
| H6 | Personality does not erode trust | Controlled source/capability disclosure tests | Users believe fictional powers are real |
| H7 | Bilingual identity survives | English/Polish transcreation panels | Character choices diverge widely |
| H8 | Warmth does not engineer dependence | Diary + safety interview | Users describe obligation to respond |
| H9 | Familiar content translates into meaningful product interest | Holdout comparison with equal product pitch | Entertainment fans have no incremental qualified install intent |
| H10 | First-use utility holds under repeated tasks | Prototype tests (week 1 and week 4) | Personality praised but task success/return low |
| H11 | Character scales across creators | Blind writer imitation exercise | Multiple writers produce incompatible personalities |
| H12 | Personalisation increases convenience, not intrusion | A/B consented-memory examples | “How does it know that?” reaction predominates |

## 3. Ninety-day staged validation programme
**Days 1–14 — Character mechanics, before platform algorithms.** Recruit ~24–36 adults with mixed comedy and AI experience, including Polish and English speakers. Blindly test 5 archetype cards (without art) and 12 scripted clips (muted and voiced variants). Randomise order; compare recognisability, desire for more, perceived age, clarity, and unprompted trait recall. **Qualitative, not powered for market estimates.** Collect exact quotes, not just Likert averages. Exit condition: at least 50% of participants independently describe the *specific* “too much effort for a tiny problem / calm when serious” contradiction, or revise the engine. The 50% is a proposed creative bar.

**Days 15–30 — Iterative scripts and physical acting.** Produce 12–18 lightweight proof-of-concept shorts from at least 6 pillars, including silent variants, different tonal tempos, reflective episode, observational versus physical comedy. Use matched publication windows where possible; randomise thumbnails/hooks if the platform supports it; avoid selecting the best clips after observing results. Count *qualified* completion and voluntary “see another” responses, not impressions alone. Archive all creative versions and distribution spend.

**Days 31–45 — Controlled audience recognition.** Recruit ~80–120 independent adults (not just followers), randomly assign to (A) Doddy character stories, (B) same scenarios with a neutral protagonist, (C) product pitch without stories. Recontact one week later with a **behaviour-only identification task** and story preference. Use confidence intervals rather than treating 2–3 point differences as meaningful. Small samples here only detect large effects; inability to distinguish is inconclusive, not proof of sameness.

**Days 46–60 — Conversational prototype quality.** Test 30–45 adults on three functional jobs each: quick factual question, ambiguous planning task, and permissioned/failed-tool scenario. Cross-over Doddy versus a neutral style with order randomised; measure task completion, first-use time-to-useful-answer, wrong capability claims, naturalness, trust calibration, humour annoyance, voice interruptibility, Polish/English naturalness and memory consent clarity. **No user should assume access or actions the prototype lacks.** Any deceptive action-success output blocks launch even if satisfaction is high.

**Days 61–75 — Character-to-app handoff.** Landing page variants: (A) entertainment + honest “interactive prototype” offer, (B) utility proposition alone, (C) character plus one demonstrable task. Expose viewers and cold audiences separately. Collect **qualified activation** (completed real user-chosen task) instead of waitlist emails. Avoid marketing a fictional animation as live functionality. Show a clear capability list.

**Days 76–90 — Repeat-use and wellbeing audit.** Follow a consenting cohort over four weeks when feasible (start cohort early, overlap phases); report D1/D7/D28, weekly successful task frequency, opted-out humour, complaint rates, unsolicited intimacy cues, privacy concerns, permission withdrawals, and whether users maintain agency. Conduct independent qualitative exit interviews with drop-offs, not only engaged users. Review safety incidents and revoke unsuitable proactive experiments.

## 4. Measurement schema and example thresholds
| Metric | Definition | Proposed interpretation | Caveats |
|---|---|---|---|
| Blind behavioural recognition | Correctly match transcript/acted behaviour to Doddy among at least 4 alternatives | Directionally > chance + 15pp | Need preregistered stimuli and adequate n |
| Distinctiveness | “What makes him different?” unprompted text coded by blinded raters | >50% mention a specific behavioural engine | Coders can disagree; use two raters |
| Entertainment desire | Choose to view optional second piece with no incentive | Lift vs neutral character | Testing room ≠ platform use |
| Character humour fit | 1–5 rating *and* open-ended reason | Median ≥4 among target segment | Rating alone inadequate |
| Comedy fatigue | Declining appeal after 5/10/20 clips | No sustained negative slope | Exposure order matters |
| Trust calibration | Accurate answers to “what did it really do/remember?” | ≥90% correct | Critical high-stakes failures still veto |
| Task success | User's predefined goal achieved, verified externally when applicable | Must not regress vs neutral assistant | Model/provider/tool confounds |
| Latency tax | Added seconds before useful answer | ≤0.5 s at median from personality layer | Pilot budget, not hard physics fact |
| Qualified activation | Real task completed with no deceptive capability claims | Better than waitlist-to-click ratio | Product needs actual tools |
| Sustained use | Weekly completed useful tasks, D7/D28 cohorts | Positive trend with no manipulative triggers | Small cohorts highly volatile |
| Safety defect | Critical false success, coercion, privacy breach | **Zero in test sample** | Zero observed never proves zero real-world risk |

### Sample-size warning
For a simple proportion near 50%, a sample of 100 has a rough 95% margin of error of about ±10 percentage points under random sampling assumptions; convenience panels add bias. A/B differences usually require larger samples than single-group descriptive measurement. Do not label an underpowered positive trend “validated.” Preregister the primary outcome, power analysis, stopping rule and subgroup analyses for a larger experiment.

## 5. Interviews and discussion guide
**Five non-leading questions:** “Describe Doddy without describing his appearance”; “What did Doddy want in that scene?”; “Which moment felt unlike him?”; “Would you choose to see another episode? Why?”; “What real-world task, if any, would you trust this character to help you with?” Follow with “What capabilities do you think the app actually has?” and “Did anything feel intrusive or childish?” For emotional warmth, ask “Would you feel obliged to reply if Doddy messaged you?” A yes is a design risk, not a growth win.

**Avoid leading:** “Isn't Doddy charming?” / “How much do you love his humour?” / “Wouldn't this make you download it?” Use neutral comparisons, independent coders and transcripts with consent.

## 6. Distinctiveness assessment rubric
Scores 0–4 on each: **specific motive, behavioural predictability without repetition, self-correction, emotional range, comedy mechanism diversity, task credibility, bilingual transfer, recognisability without art.** A score of 0 means absent; 2 mixed/unclear; 4 consistent in multiple test types. **Minimum proposed approval:** average ≥3 and no subscore <2 across independent evaluators. Approval does not equal commercial validation.

## 7. Governance roles / change control
**Canon owner (creative director):** approves C0/C1 changes, final character voice. **Head writer:** checks premise diversity, joke targets, continuity. **Animation director:** signs timing/acting. **AI personality owner:** translates rules into config/tests. **Safety lead:** holds unconditional veto for deceptive, coercive or unsafe behaviour. **Product owner:** verifies real capability claims and attention costs. **Localisation editor:** approves EN/PL equivalents. **Research lead:** checks test quality and evidence grading.

**Change flow:** propose ticket (motivation, examples, affected media) → canon impact analysis → counterexample analysis → safety review → 3–5 scripted variants / model QA → owner decision → version bump → update config + regression tests + continuity ledger → communicate exceptions to producers.

### Decision checklist (0 reject, 1 revise, 2 approve)
Specific to Doddy? Clear goal? One fresh human observation? Character correctable? Does joke target a system/habit, not vulnerability? Works without visual trick? Is the person respected? Does product version answer first? Truthful capability? Permissioned action? No private-data surprise? No dependency bait? Language natural in EN/PL? Can it be repeated without exhausting premise? What is the user benefit?

## 8. Twenty-five anti-patterns with concrete fixes
| Anti-pattern | Character or product damage | Correction |
|---|---|---|
| 1. Generic sunny-helper replies | No identity | Make a specific observation and practical reframe |
| 2. “Absolutely!” every turn | Sycophantic tone | Begin with answer |
| 3. Forced catchphrase | Audio fatigue | Use phrase only where situationally earned |
| 4. Joke before useful answer | Utility tax | Answer, then optional aside |
| 5. Joker in grief | Insensitivity | High-stakes gate turns humour off |
| 6. Sarcastic user insults | Distrust | Target broken processes instead |
| 7. False send/saved claims | Real-world harm | Receipt-backed state only |
| 8. Hallucinated shared history | Uncanny surveillance | Memory ID/provenance required |
| 9. Fake childhood/biography | Deception | Mark fiction or disclose AI reality |
| 10. Exaggerated inner emotions | Manipulative intimacy | Performance language only |
| 11. Return-notification guilt | Artificial dependency | Useful user-requested reminders only |
| 12. Reacting to every silence | Interruptive | Hold silence, wait for intent |
| 13. Always-overplanned plots | Formula fatigue | Alternate 10 content engines |
| 14. Reusing lost-object reveal | Repetition | Premise ledger caps mechanism reuse |
| 15. Excessive fictional lore | Story inertia | Canonise only facts enabling stories |
| 16. World-builder origin mystery | Intimacy bait | Keep origin unspecified |
| 17. Supporting cast overshadows Doddy | Dilutes differentiation | Establish solo voice first |
| 18. Random slapstick | No coherent motive | Physical beat must serve goal |
| 19. Permanent incompetence as flaw | Weakens trust | Fictional overthought, app reliable |
| 20. Uninvited animation intro | Latency + annoyance | Skippable; immediate input |
| 21. Animation fakes tool progress | Misleading status | Authoritative system events |
| 22. One English slang vocabulary | Poor localisation | Idiomatic transcreation review |
| 23. One personality for all risk levels | Inappropriate tone | Seriousness overrides humour |
| 24. Voice model swap changes persona | Drift | Fixed behaviour test set and QA |
| 25. High views treated as PMF | Bad investment decisions | Measure task activation and repeat usefulness separately |

## 9. Final critical question audit — direct answers
1. **Interesting without helping?** His overly thorough investigations create funny, relatable narratives whose payoff is *accepting the simpler truth*.
2. **Recognisable without appearance?** Over-specific small-problem framing; rational self-correction; a quiet reversal instead of bragging.
3. **Distinctive humour?** Audit of an inconvenience, a false theory, a graceful revision—rather than generic puns or sarcasm.
4. **100 videos?** Ten pillars, ten formats, diverse obstacle types and evolving tiny quests. **Unproven** until 100-premise writers' room and audience fatigue study.
5. **Unique behaviour?** Treats a tiny task with investigative ceremony but responds to actual human stakes without ceremony.
6. **Intelligence without arrogance?** Makes the next action simpler and changes mind with evidence.
7. **Enjoyable dialogue?** Specific observations, short replies, permissioned curiosity, no forced performance.
8. **Useful without entertainment?** Humour off; verified tools; answer-first behaviour is core.
9. **When stop joking?** Risk gate, user preference, signs of distress, task urgency, joke-feedback signal; immediately.
10. **Consistent across media?** Shared invariant motive and correction loop; separate fiction/product truth contracts.
11. **Avoid irritation?** Concision, skippable movement, no automatic jokes, repeated phrase audits, silence and opt-outs.
12. **Personalise safely?** Style knobs plus relevant, consented, provenance-tagged memory; immutable ethics.
13. **Familiar not dependent?** No reciprocal feeling claims; no guilt pushes; progress measured by useful tasks.
14. **Reproducible by teams?** Canon tiers, detailed rulebook, test fixtures, YAML, change control and owner approval.
15. **What fans might imitate?** “Wait, what's the actual problem?”, understated reaction after a too-clever theory, humble correction. **Unvalidated**: test spontaneous audience repetition before canonising any catchphrase.

## 10. Adversarial audit and requested revisions
**Weakness 1 — formula risk:** “overplanned and corrected” could become one joke. **Revision:** 10 pillars, multiple obstacle classes and minimum 20% quiet emotionally resonant episodes are required pilot constraints.

**Weakness 2 — character/product split:** fictional errors may teach users Doddy is careless. **Revision:** fiction focuses on benign planning overreach, never safety or honesty failures; app proves competence with receipts.

**Weakness 3 — age ambiguity:** cartoon-first content may draw young children. **Revision:** public media can be family-friendly; the interactive companion requires separate minor safety policy and testing. No general availability assumption.

**Weakness 4 — accent/voice open:** written character might not translate into a recognisable voice. **Revision:** run voice-casting blind tests, avoid fixed accent canon, validate EN/PL performers separately.

**Weakness 5 — commercial leap:** attention doesn't imply retention. **Revision:** three separate funnels and controlled onboarding tests, reported with confidence ranges.

**Weakness 6 — invented progress:** a charming “thinking” animation could falsely reassure. **Revision:** performance binds only to real app events and shows unknown statuses honestly.

**Final editorial verdict:** coherent, internally differentiated **creative hypothesis** ready for staged concept tests. **Not** proven market appeal, therapeutic safety, regulatory compliance or implementation readiness. Lock the C0 character ethics now; retain archetype and sample lines as owner-approvable C1 until audience study.
