# DODDY — Character-First AI Companion | Research Package
**As-of date: 8 October 2026**

## What is included

| File | Description |
|---|---|
| `01_Research/DODDY_Strategic_Research_Report.pdf` | 10-page sourced, skeptical research report: market demand, character-led cases, current competition, retention, economics, 22 risks, 90-day validation and final verdict. |
| `01_Research/DODDY_Strategic_Research_Report.md` | Editable source text for the report. |
| `01_Research/DODDY_Executive_Decision_Memo.md` | One-page founder decision memo. |
| `02_Deck/DODDY_Strategy_Deck.pptx` | Editable 36-slide 16:9 deck (30 main slides + 6 appendix slides). Text, vector character/diagrams, and mockups are editable PowerPoint elements. |
| `02_Deck/DODDY_Strategy_Deck.pdf` | PDF rendering of the 36-slide deck. |
| `03_Data/DODDY_Evidence_Database.xlsx` | Editable evidence database, 53 traceable findings from 23 sources. |
| `03_Data/DODDY_Evidence_Database.csv` | Spreadsheet-compatible copy for review/import. |
| `03_Data/DODDY_Financial_Model.xlsx` | Editable 12-month 3-scenario financial and voice-use sensitivity model, based on transparent assumptions and formulas. |
| `03_Data/research_sources.json` & `evidence.json` | Structured backing dataset with source URLs, publication dates and evidence caveats. |
| `04_Validation/DODDY_90_Day_Plan.md` | Eight experiment plans, day-by-day/weekly execution, metrics, sample targets and GO/PIVOT/STOP decision gates. |

## Verdict

**VALIDATE FIRST.** Test a narrowly useful memory/follow-through companion and Doddy's content persona **in parallel**. Do not fund full general agent capabilities until real users demonstrate repeated useful action and positive unit economics. Suggested incremental 90-day test cash cap: **$5k–$15k**, excluding founder time and already-built prototype.

## Important limitations

- This is **secondary research**; no interviews, beta use-data or trials were conducted. **No product-market fit has been demonstrated**.
- **53 findings from 23 sources are not 53 independent studies**. Several findings come from Pew and RevenueCat data tables and should not be treated as independent confirmation.
- Most quantitative adoption sources concern US adults or US teens; Poland/EU demand remains an evidence gap.
- Character/conversion effect is unproven. Duolingo and Talking Tom are *weak commercial analogies* for content-first productivity AI.
- Financial conversion, pricing, churn and production spend are editable **hypotheses**, not estimates or audited forecasts. App Store and API pricing varies with geography and date.
- The deck's cartoon is **a new vector representation from the written Doddy character description**, not a verified exact match to any prior reference image; confirm against approved brand art before public use.
- Technology and EU regulatory content is a launch checklist, not legal/security sign-off. Review original provider docs and seek qualified legal counsel before release.

**Source-of-truth:** `03_Data/DODDY_Evidence_Database.xlsx` and `03_Data/research_sources.json` for public claims; `03_Data/DODDY_Financial_Model.xlsx` for explicitly hypothetical financial outputs.
