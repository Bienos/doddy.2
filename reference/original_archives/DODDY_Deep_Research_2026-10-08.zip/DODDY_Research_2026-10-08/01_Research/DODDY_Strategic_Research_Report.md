---
title: "DODDY | Character-First AI Companion"
subtitle: "Independent strategic validation · Research current to 8 October 2026"
author: "Research assessment"
date: "8 October 2026"
geometry: margin=0.75in
fontsize: 10pt
colorlinks: true
linkcolor: orange
---

# Executive decision

**VERDICT: VALIDATE FIRST.** Doddy deserves a focused, time-boxed test, not a full consumer-agent build. AI chat use is mainstream and approachable, character-based experiences are commercially plausible, and an animated companion precedent already exists. But no reliable public study establishes that *social followers of a new fictional AI character* become retained paying users of its separate assistant app. That conversion is Doddy's critical unproven bridge.

**Recommended execution:** run character content and a narrow functioning app prototype **in parallel** for 90 days. Do not spend six months creating a massive content following before testing software demand. Do not compete with ChatGPT/Gemini/Meta Muse on breadth or frontier intelligence. Test an adult-oriented, delightful **remember → retrieve → follow-through** job, delivered by a recognizable character with optional voice. Keep the character entertaining in marketing and efficient in practical tasks.

**Initial capped budget:** $5,000–$15,000 in incremental experimental cash spend (excludes founder time and already-built prototype). Pay more only if observed users, not follower counts, justify it. These are recommended caps, not surveyed market prices.

**Decision in 90 days:** GO to a limited paid beta only if independently acquired people perform useful tasks repeatedly and show credible payment behavior. PIVOT if entertainment outperforms the app. STOP the companion business if character engagement never generates app demand *or* users abandon the product after novelty disappears.

# 1. Define the opportunity correctly

Doddy is proposed as two linked businesses. Entertainment creates attention and character recognition. Software provides useful outcomes and, potentially, paid subscriptions. They compete with different alternatives, optimize different metrics, and may succeed or fail independently. Refer to the supplied concept brief for original scope.

| Business | Users come for | Success metric | Monetization | Biggest vulnerability |
|---|---|---|---|---|
| **Doddy the Character** | Stories, humor, personality, familiarity | Returning viewers, branded direct searches | Sponsorship/IP/licensing *if proven* | No connection to product demand |
| **Doddy the App** | Help, memory, continuity, action | Retained users, successful tasks, paid renewal | Subscription or metered premium capability | General assistants already suffice |
| **The bridge** | "I watch Doddy; now I can use him" | Attributed activation and D30 retention by content cohort | Lower effective CAC *if demonstrated* | Followers don't install, or install then churn |

**The core hypotheses:** (A) users remember and enjoy Doddy; (B) viewers develop product curiosity; (C) some download; (D) first sessions create useful results; (E) users return unprompted; (F) sufficiently many are willing to pay; (G) cost to serve stays below net receipts. Each is a separate gate. Hypotheses A and B do not prove D–G.

# 2. Evidence — what is established versus inferred

## 2.1 Demand for AI is clear; demand for another agent is not

Pew surveyed **5,119 US adults** in February 2026. **49% had ever used AI chatbots**, and **24% reported daily use**. Of all US adults, **42%** used chatbots to search for information, **25%** for entertainment, **10%** for emotional advice and **4%** for companionship. ChatGPT had ever-use reach of **44%**, compared with Gemini **24%** and Character.ai **3%**. These categories suggest a **useful assistant with entertainment appeal** is better grounded than a pure friend positioning. These are **US adoption statistics**, not Poland-specific market rates and not subscription intent. [Pew, 17 June 2026](https://www.pewresearch.org/internet/2026/06/17/americans-and-ai-2026-chatbots-smart-devices-and-views-on-impact/).

Across ages, **61% of 18–29-year-olds** and **55% of 30–49-year-olds** had used ChatGPT. A young-adult segment therefore is familiar with the category but also knows the incumbents. [Pew detailed tables](https://www.pewresearch.org/internet/2026/06/17/americans-and-ai-appendix-detailed-chart-and-tables/).

**Interpretation:** global TAM slides built from every AI user would be misleading. Doddy's serviceable early market is people whose recurring daily job, frustration and willingness-to-pay can be observed in a live test. A 90-day regional beta cannot establish global TAM.

## 2.2 Subscription outcomes are not guaranteed by downloads

RevenueCat's 2026 analysis reports **2.4% median download-to-paid conversion in AI apps**, compared with **2.0% for non-AI apps**; median trial-to-paid was **8.5%** vs **5.6%**. However, just **6.1% of AI monthly-plan subscribers were retained at 12 months**, versus **9.5%** of non-AI monthly-plan subscribers. For annual plans the figures were **21.1% vs 30.7%**. AI apps' median **year-one realized revenue per payer** was **$30.16**, with caveats about product mix and sample composition. These figures **are not** a forecast for Doddy or universal category causal effects. [RevenueCat State of Subscription Apps 2026](https://www.revenuecat.com/state-of-subscription-apps).

**Interpretation:** a popular app-store launch can convert and still have unsustainable lifecycle economics. Measure cohorts, *not* just gross downloads or a social waitlist.

## 2.3 Character psychology is plausible but not yet a commercial bridge

A [2026 paper in *Journal of Retailing and Consumer Services*](https://www.sciencedirect.com/science/article/pii/S0969698925004916) examined parasocial relationships and brand advocacy in four experiments concerning podcast hosts. A separate [three-experiment 2026 study](https://www.frontiersin.org/journals/psychology/articles/10.3389/fpsyg.2026.1730776/full) examined how cuteness style and perceived brand warmth/competence can affect brand evaluations. These findings support *plausible mechanisms* for familiarity and affection. Neither demonstrates that an animated AI mascot improves a standalone assistant's D30 retention or willingness-to-pay. **Evidence strength: moderate for emotional familiarity, weak for profitable character-to-app conversion.**

## 2.4 AI attachment is real — and carries costs and safety responsibilities

Common Sense Media's survey of **1,060 US teens** reported **72%** had tried AI companions, **52%** used them regularly and **13%** used them daily. This is evidence of participation, *not* an appropriate initial audience for Doddy. [Common Sense Media, July 2025](https://www.commonsensemedia.org/research/talk-trust-and-trade-offs-how-and-why-teens-use-ai-companions).

A [four-week randomized research study with 981 participants](https://arxiv.org/abs/2503.17473) observed that heavier chatbot use was associated with more problematic dependence and loneliness in measured outcomes, while effects varied by interaction mode and conversation type. Do not infer that chatbots cause every observed harm from correlations embedded in the study. A separate [21-day randomized study, n=183](https://arxiv.org/abs/2509.19515), did **not** find significant overall social-health differences between companion-chat and word-game conditions; anthropomorphism varied with users' pre-existing social needs. Neither supports maximizing daily emotional screen time as Doddy's North Star.

**Product principle:** encourage real-world action, transparent AI identity and graceful exit, not exclusivity, guilt or dependency.

# 3. Comparable businesses — mechanisms, not just aesthetics

| Case | Verified facts / sequence | Positive lesson | Transferability / caveat |
|---|---|---|---|
| **Duolingo / Duo** | Reported **50m+ daily active users** at end-2025. A specific TikTok awards case reported **34.8m campaign impressions**, **26.9m reach**, **12.63% engagement**. | A recurring mascot persona can drive recognizable narrative attention. | **Weak to moderate:** product and language-learning habit existed before current mascot-led strategy. Campaign reach ≠ attributed paying customers. Sources: [investors](https://investors.duolingo.com/news-releases/news-release-details/duolingo-reports-fourth-quarter-and-full-year-2025-results), [TikTok](https://ads.tiktok.com/business/en/inspiration/ad-awards-duolingo-case-study). |
| **Talking Tom / Outfit7** | The original talking-cat mobile game launched in 2010; had **1.5bn+ downloads** by its 2025 anniversary. Company says franchise has **26bn+ cumulative game downloads**, **119bn+ lifetime video views**. | Interactive character can become entertainment IP. | **Weak direct analogy:** app-first and game/children's media, not short-video-first then productivity assistant. Sources: [Outfit7 original](https://outfit7.com/blog/news/15-years-of-talking-tom-cat-a-classic-returns), [company](https://outfit7.com/our-story). |
| **Tolan** | A stylized non-human animated AI companion; *Wired* reported 100k+ monthly users in 2025. | Direct precedent that expressive character AI has a consumer use case. | **Strong conceptual competitor**, but metrics are journalistic/company sourced and are not independently verified profitability. [Wired](https://www.wired.com/story/tolan-chatbot-ai-companion). |
| **Character.AI** | Character conversation and roleplay product. Removed under-18 open-ended chatbot conversations starting Nov 2025. | Characters can be the core interaction product. | Its roleplay demand and safety posture differ from reliable task assistance. [Company policy](https://blog.character.ai/u18-chat-announcement/). |
| **Meta Muse** | Personal task-capable AI agent launched Sept 2026 with messaging and connected-app claims. | The competition is shifting from answers to actual execution. | Meta's ecosystem/distribution raise acquisition barriers. Features are vendor claims until independently benchmarked. [Meta](https://about.fb.com/news/2026/09/introducing-muse-personal-ai-agent/). |

**Missing proof:** comparable, audited content-reach→iPhone-install→90-day-paying-retention conversion for *an independently created fictional character*, launching a productivity assistant second. Do not fill this absence with invented percentages.

# 4. Should Doddy be built character-first, app-first, or in parallel?

| Strategy | Advantages | Failure mode | Judgment |
|---|---|---|---|
| **Character-first then app** | Lower product commitment initially; can discover creative demand | Audience may want cartoons, not software; delays first retention data; content may be expensive | **Not the default** |
| **App-first then character** | Tests useful tasks quickly, strongest PMF discipline | Without distribution, beta may stall; generic app identity competes poorly | **Viable control** |
| **Parallel lightweight** | Tests entertainment, click-through, activation and retention together; enables in-content real task demo | Founder coordination cost; both workstreams must stay narrow | **Recommended** |

**Recommended launch order:** introduce Doddy as a **character living in the world**, but within week 3 link to a functional private beta. Let viewers see the same interaction they can perform. Avoid making Doddy's stories dependent on unshipped features. The honest promise is: *You've seen Doddy help. Now ask him to remember the little things and help you follow through.*

# 5. Proposed primary audience and first product

**First segment:** adults 18–34 who already try chatbots but lose small personal commitments across apps — early-career workers, students over 18 and multilingual urban users. They are easy to reach through relatable short-form narratives; the problem must still be verified in interviews and event logs. **Do not target minors in the first beta.**

**One primary job:** **"Tell Doddy something you'll need later; he helps you find it and act on it."** Examples: "Remember that Alex suggested the restaurant on Friday"; "Save what the mechanic said"; "Next Tuesday remind me to check the insurance"; "What was the name of that place I mentioned?" A memorable character helps onboarding, but the saved information and subsequent successful retrieval are the measurable value.

**Required MVP (not feature wish list):**

1. Native SwiftUI iPhone app with coherent character animation and low-friction text entry; voice optional, budget-limited.
2. Explicit opt-in save-to-memory, searchable/inspectable facts and source-of-memory; user can correct, hide, export and delete.
3. Calendar/reminder capability only where OS and user permissions support it; clear confirmation before external effects.
4. Fast direct answers or completions; humor must be optional and never impede practical use.
5. Privacy/onboarding disclosure, event instrumentation, account deletion, subscription only after proven usage.
6. Tool permissions and per-action confirmation; default no open browser-control powers or mailbox-wide access.

**Not in MVP:** autonomous purchases, universal screen awareness, always-on microphone, permanent Dynamic Island friend, continuous background voice, automatic reading of all phone content, open-ended "can do everything" marketing, emotional dependence loops, unrestricted teen access. Translator mode is a possible *controlled comparison*, not the primary commitment; generic translation is easy for incumbents to copy.

**Core activation event:** a user saves a fact or task and successfully retrieves or follows it up in a later session. Ask three questions separately: was it done correctly, was it worth coming back for, and would they pay to continue?

# 6. Content universe — 10 repeatable formats

These are **creative hypotheses**, not proven organic-growth formats.

| Series | Premise | Viewer → product bridge | Production / risks |
|---|---|---|---|
| Doddy vs Forgetting | Forgets something absurd, then fixes it | Save and recall | Simple, highly relevant; gag fatigue |
| Doddy's Human Manual | Observes baffling human routines | Help think through choices | Easy repeatability; weaker activation |
| One Minute, One Rescue | Helps solve a relatable small snag | One actionable task | High product fit; demonstration must be genuine |
| What Did I Say? | Remembers past scene details | Memory continuity | Strong product fit; privacy boundaries |
| Doddy Abroad | Misunderstands a foreign-language situation | Translation/travel test | Very shareable; crowded functionality |
| Doddy's Pocket Notes | Tiny sketches of life admin | Capture → reminder | Strong habit fit; may feel mundane |
| Human vs Doddy | Characters race to complete chore | Task completion / benchmark | Clear benefit; risk of fake capability |
| Doddy After Work | Comedic everyday decompression | Planning and reflection | Likable; avoid dependency framing |
| Doddy Asks Why | Curious explanations of odd truths | Research / explore | Strong evergreen content; generic search |
| Doddy's Comeback | Callback to an earlier adventure | Continuity | Serial attention; not necessarily utility |

**Production discipline:** create three reusable backgrounds, expressive face poses, a clean rig, one sonic motif and punchy captions. Repurpose each hero concept into multiple platform-native cuts. Avoid creating 60 custom animated films before measuring repeat viewers or signup conversion.

# 7. Product and iOS feasibility

| Surface | Feasibility as of Oct 2026 | Constraint / recommended role |
|---|---|---|
| SwiftUI app and animated Doddy | Supported | Main experience; optimized animation and accessibility |
| App Intents / App Shortcuts | Supported with mode restrictions | User-invoked save/remind/search intents; not unrestricted system takeover |
| Back Tap shortcut | User configuration dependent | Can be taught in onboarding; cannot set device-wide Back Tap binding automatically |
| Widgets and Lock Screen widgets | Supported within platform design constraints | Glanceable reminder/status, not an unrestricted assistant process |
| Dynamic Island / Live Activities | Supported **for legitimate bounded activities** | Apple specifies up to **8h active**, and max **12h Lock Screen persistence**; not a permanent interactive mascot. [Apple](https://developer.apple.com/documentation/activitykit/displaying-live-data-with-live-activities). |
| Always-listening across apps, unlimited persistent overlay | Not a credible ordinary third-party iOS capability | Avoid promotional claims |
| Background agent actions | Scoped / approval / API dependent | App Intents run modes constrained by intent and OS. [Apple](https://developer.apple.com/documentation/appintents/configuring-the-runtime-behavior-of-your-app-intents). |

**Technical architecture:** SwiftUI frontend → local protected memory index/storage → explicit capture/retrieval pipeline → entitlement-checked voice/text orchestration service → audited tool registry → vendor model(s). Separate: `transient conversation`, `user-approved persistent memory`, `task state`, `tool credentials`, `analytics events`. Never write the entire raw transcript to indefinite long-term memory by default. Derive structured reminders from user-confirmed intent. Each memory needs creator/source, timestamp, user-edit status, deletion lineage and confidence. Instrument `save_success`, `recall_success`, `reminder_fired`, `reminder_acknowledged`, `failed_action`, `subscription_renewed` while minimizing content in telemetry.

# 8. EU legal, privacy and trust assessment (not legal advice)

**AI Act:** From **2 August 2026**, Article 50 transparency requirements apply in the EU. Doddy must disclose that it is an AI system; applicable synthetic/generated content labels also require assessment. A stick figure that jokes like a human must not mislead users about being human. [European Commission](https://digital-strategy.ec.europa.eu/en/news/commission-starts-enforcing-ai-act-rules-and-new-transparency-requirements-2-august); [Article 50](https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-50).

**GDPR:** local-first storage can reduce transfers and risk but does not automatically make the service anonymous or exempt its controller/processor obligations. The EDPB stresses case-by-case anonymity and a legitimate-interest assessment, where relied on, for personal-data use in AI. [EDPB opinion](https://www.edpb.europa.eu/news/edpb-opinion-on-ai-models-gdpr-principles-support-responsible-ai_en). Practical launch checklist: determine controller/processor roles and Article 6 legal bases by processing purpose; disclose model and hosting recipients; execute DPAs and relevant transfer safeguards; minimize raw audio; build access/rectification/deletion/export; define retention schedules; avoid processing sensitive Article 9 information unless an appropriate lawful exception and safeguards apply; assess DPIA need; restrict third-party analytics; get appropriate consent for nonessential tracking; protect actions with per-tool scopes and explicit confirmations.

**Safety:** Character.AI's 2025 decision to remove open-ended chat for under-18 users is a concrete warning, not a universal legal rule. Launch adults only, with age gating proportionate to risk; implement crisis responses, anti-sycophancy boundaries, opt-out/quiet modes, and a ban on simulated exclusivity ("only I understand you") or guilt-based notifications. [Character.AI](https://blog.character.ai/u18-chat-announcement/).

**Trust differentiator to test:** allow the user to see *exactly what Doddy remembers* and which app permissions are connected. Users should be able to use basic chat without granting calendar, contacts, microphone or location access.

# 9. Illustrative economics and funnel — assume nothing is validated

The editable workbook models three 12-month cases with a **$9.99/month consumer price including an illustrative 20% VAT**, **15% platform fee** assuming Small Business Program eligibility, **$0.05/minute voice list cost**, cash/economic development spend and declining retained customer cohorts. 20% is a simplified modeling placeholder rather than a definitive VAT treatment. Vendor and country prices require recheck. OpenAI's listed GPT-Live voice price is **$0.05 per minute** with additional backend/model/tool charges. [Vendor pricing](https://platform.openai.com/pricing). Apple separately lists a **15%** EU IAP Small Business Program rate where eligible. [Apple EU payment terms](https://developer.apple.com/support/payment-options-on-the-app-store-in-the-eu).

**One-million-view illustration:** 1,000,000 impressions × 0.1% click-through × 30% click-to-install × 5% installed-to-paid = **15 new paid accounts**. At $9.99 gross each, that is only **$149.85 in monthly billings** before tax, store costs, inference costs, churn and content costs. Every conversion rate in this example is an assumption; it is not a market estimate. The example demonstrates the sensitivity of the bridge.

**Voice-price cliff:** 5 min/day × 30 days × $0.05/min = **$7.50 in voice API cost per paying user per month**. A $9.99 inclusive-VAT subscription produces about **$7.08 after illustrative VAT and a 15% platform cut**, *before* any other AI tokens/storage/support. Such a tier loses contribution even before fixed costs. A product designed for long casual voice hangouts may require much higher subscription pricing or materially cheaper models. Voice must be capped, metered, optimized or bundled into premium tiers only when usage economics are proven.

The model's 12-month **cumulative economic results are negative in all three deliberately cautious scenarios** with the input development/content cost allocation, including the upside scenario. This is **not a forecast**. It means current hypothetical traction is insufficient to justify an expensive production organization; the route to profit must be demonstrated through actual conversion, retention, cheaper delivery, price, distribution or another revenue channel. Open `DODDY_Financial_Model.xlsx` to change assumptions and examine how conclusions move.

**Metrics for real experiments:** views from unique viewers; profile/direct link click rate; click→install; install→useful first task; useful-first-task→next-week repeat; week 4 active share; install→paid and paid retention; mean/p95 cost per meaningful completion; median voice minutes paid user/day; support incident rate; opted-in memory correction/deletion frequency. Source track by content series and by paid vs organic.

# 10. Red team — 22 ways the idea fails

*Ratings are analyst judgment, not objectively measured probabilities. H/M/L refer to relative likelihood given current assumptions.*

| # | Failure mechanism | Severity / likelihood | Early signal | Mitigation / business kill? |
|---|---|---|---|---|
| 1 | People like cartoons, not utility | Critical / H | views without clicks | Mixed app demos; kill paid-app thesis if persistent |
| 2 | First-use novelty decays | Critical / H | no D7/D30 repeat | Define meaningful action; kill if no use-case demand |
| 3 | ChatGPT/Gemini already sufficient | Critical / H | no compelling switch story | Pick one job incumbents do poorly; possible kill |
| 4 | Tolan/other mascots differentiate similarly | High / H | comparison users see no difference | Focus tangible service and relationship; possible kill |
| 5 | Personality becomes annoying | High / M | mute voice/animation | Fast, quiet mode; humor budget |
| 6 | TikTok audience skews under 18 | High / H | lots of young followers | Adult targeting and age gates; reposition content |
| 7 | Marketing reaches but cannot attribute | High / M | no link-tagged conversions | URLs, promo codes, matched cohorts |
| 8 | Animation cost scales faster than reach | High / M | high cost per returning viewer | Rig, templates, batching; cap costs |
| 9 | Viral spike disappears | High / H | overconcentrated distribution | Repeat-viewers across channels |
| 10 | App-store conversion remains weak | Critical / H | low content→install | Test real activation payoff; can kill |
| 11 | Subscription uptake fails | Critical / H | users decline real payment | Meter costs, simplify value; can kill |
| 12 | AI voice margin becomes negative | Critical / H | >~5min/day at $9.99 | Quotas/cheaper model/higher price; can kill |
| 13 | Incorrect memory harms trust | Critical / M | wrong recall and corrections | Source-backed memory / confirmations; can kill |
| 14 | Unsafe tool actions | Critical / M | unauthorized sends/changes | Approval barriers/least privilege; can kill |
| 15 | Hallucinated task completion | Critical / M | reported done vs actual fail | Verified tool receipts, no false "done" |
| 16 | Data breach / vendor exposure | Critical / M | security findings or incidents | Encryption, DPA, minimization; can kill |
| 17 | Emotional dependence or manipulation | Critical / M | exclusive attachment phrases | Guardrails and healthy exit; can kill |
| 18 | Teen safety problem | Critical / M | underage access, unsafe chats | Adult-only, age gates, expert review; can kill |
| 19 | Cannot run continuously on iOS | High / H | feature depends on background | Honest OS-native constraints |
| 20 | Dependency on model vendor/prices | High / H | quality/pricing break | Model routing, evals, graceful degrade |
| 21 | EU transparency/GDPR noncompliance | Critical / M | undefined lawful basis | Legal/privacy review before general launch; can kill |
| 22 | Character IP weak or ownership unclear | High / M | copied look / no assignments | Rights assignments, trademark counsel, asset provenance |

**Most severe correlated scenario:** viral character → expensive animation cadence → low app conversion → promotional discount → heavy voice users → negative margin → inevitable budget exhaustion. This is more dangerous than any single isolated risk.

# 11. Ninety-day validation design

See `04_Validation/DODDY_90_Day_Plan.md` for operational experiments and criteria. Every threshold below is a **founder decision rule**, not an industry benchmark.

**Days 1–14: baseline and controls.** Instrument the existing prototype, conduct 15–20 adult need interviews, recruit a mixed beta panel, and set privacy/AI identity basics. Pre-register content series and a control app pitch without character narrative. Test whether the target audience actually experiences the chosen memory/follow-through job weekly.

**Days 15–35: awareness vs intent.** Produce 15–24 low-cost shorts split among story-only, demonstration-led and a direct no-character functional explainer. Track repeat viewers, profile CTR, qualified adult waitlist and app activation. Keep production spend capped. Test aided and unaided recognition with a blinded small panel.

**Days 36–65: usefulness vs charm.** Invite 50–100 consenting adult testers. Randomly assign a character-rich vs stripped-down interface where ethically and technically practical. Track task success (independently verified), speed, satisfaction, repeat access and memory-error rate. Acknowledge that sample sizes do not establish small effects with high confidence.

**Days 66–90: payment and retention.** Offer a clearly priced real paid beta or valid pre-purchase/checkout test with transparent delivery terms, monitor payer cost, actual D7 and early D30 retention by cohort, and compare viewing/installed/activated user segments. Do not treat surveys expressing willingness-to-pay as equivalent to completed purchases.

**GO condition (conjunctive):** repeated intentional use by a meaningful share of non-friend testers, verified task success, trustworthy data handling, initial real paid commitment, controllable marginal voice costs, and a distribution channel that links views to activated users. **PIVOT:** viewers love Doddy but product use is sparse; build entertainment/IP or a narrower utility, not the broad assistant. **STOP:** repeat task-use or verified paid demand are absent even after a focused iteration and the unit economics remain negative.

# 12. Hypothesis confidence and decision

| Hypothesis | Assessment | Evidence explanation |
|---|---|---|
| A: a mascot can create familiarity | **Moderate** | Brand studies and Duo/Talking Tom analogies; not Doddy-specific causal proof |
| B: character-first lowers CAC | **Unsupported for Doddy** | No validated content-to-retained-payer data; favorable case studies not comparable |
| C: people use conversational AI repeatedly | **Strong** | Pew 2026, widespread repeat activity and subscription data |
| D: a character improves app retention | **Weak** | Plausible psychology, missing product A/B proof |
| E: Doddy beats existing assistant | **Unsupported** | Incumbent functionality/distribution and Tolan precedent |
| F: memory/follow-through could become wedge | **Weak / testable** | User-job hypothesis aligned with common pragmatic use; unvalidated for Doddy |
| G: premium voice can be profitable | **Contradicted under unlimited cheap voice plan** | Vendor cost arithmetic; possible with quota and price adjustment |
| H: small team can validate cheaply | **Moderate** | Existing prototype reduces build work; creative and security scope remain real |

## Final recommendation

**VALIDATE FIRST — parallel character + narrow app; cap incremental 90-day spending at $5–15k; do not build a general-purpose autonomous phone agent now.** Market position: **"Doddy remembers the little things so you can get on with life."** Character voice: witty when invited, competent by default, transparent about being AI, user-controlled memory. First job: capture, later retrieve, and follow through. The only credible scale-up trigger is observed useful repeat behavior plus reliable paid unit economics. The most likely failure is building a popular cartoon while the product remains optional.

# Source note

The accompanying evidence spreadsheet contains **53 traceable findings from 23 identified sources**, each with date, geography, denominator, relevance, quality and limitation. Some rows are multiple *different* statistics from the same source; **53 rows do not mean 53 independent studies**. Sources emphasize public US data; independently validated Poland/EU behavior remains a research gap. Economic spreadsheets use explicitly editable **illustrative assumptions** rather than forecasts. This assessment has not interviewed prospective Doddy users or tested the existing prototype. No claim of product-market fit is warranted.
