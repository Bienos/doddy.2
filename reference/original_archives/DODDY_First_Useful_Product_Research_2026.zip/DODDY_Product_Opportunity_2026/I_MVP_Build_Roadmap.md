# I — Implementation Roadmap
**Not calendar commitments.** Workstreams should be sequenced by value and real engineering verification, not aspirational release dates. Individual effort depends on developer availability, code quality and test devices.

## Milestone sequence
| Phase | Deliverable | Gate |
|---|---|---|
| R0 — Verify code and constraints | Test matrix with commit SHA, known defects, device traces | No blocking crash; implementation claims reconciled |
| R1 — Reliable local memory | P0 core flow that survives restart, storage errors | 100% acknowledged writes survive relevant fault tests |
| R2 — Consent and instrumentation | Privacy QA, metrics definitions and data export | No note/transcript content in events; permissions optional |
| R3 — Usability challenge | Counterbalanced task performance report | No unexplained personal misstatements; target time/effort advantage |
| R4 — Organic utility pilot | Recall/substitution cohort results and error audit | Pass preregistered behavioural and safety gates |
| R5 — Targeted expansion test | Separate device QA, cost and usefulness analysis | Demonstrated incremental user outcome without core regressions |
| R6 — Commercial decision | Price evidence + cohort contribution economics | Proceed to scale only if usage and economics justify it |


## Priority backlog and dependencies

| Ticket | Priority | Action | Dependency | Completion evidence |
|---|---|---|---|---|
| D-01 | P0 | Reconcile README, feature matrix, actual running app | none | Signed test matrix; exact SHA |
| D-02 | P0 | Remove mandatory simulated demo sign-in for first save | D-01 | Fresh install save works |
| D-03 | P0 | Design one capture/find native journey | D-01 | Usability pilot with real text |
| D-04 | P0 | Replace UserDefaults array with protected transactional store | D-01 | atomic write/migration/failure tests |
| D-05 | P0 | Bind `LocalRecallService` to native source-aware search | D-03,D-04 | local candidate IDs and provenance |
| D-06 | P0 | Add original/edited, correction, deletion, export | D-04 | restart/edit/delete/export fixtures |
| D-07 | P0 | Remove/segregate seeded demo examples | D-04 | no samples treated as personal |
| D-08 | P0 | Add explicit incomplete-query and no-match paths | D-05 | query fixture pass |
| D-09 | P0 | Add accessibility and offline coverage | D-03–D-08 | actual iPhone device matrix |
| D-10 | P0 | Build consent, privacy and content-free analytics | D-04 | security/privacy review and schema validation |
| D-11 | P0 | Prepare 28-day research build | D-01–D-10 | tested TestFlight, rollback plan |
| D-12 | P1 | Test foreground real dictation | D-01,D-03 | supported languages, time/correction/cost measured |
| D-13 | P1 | Implement typed Apple Reminders proposal/write | D-01,D-04 | EventKit confirmed IDs, permission failures tested |
| D-14 | P1 | Control Center on supported iOS | D-03 | extension, invocation test |
| D-15 | P1 | Semantic recall with citations | real query dataset | beats baseline; no fabricated sources |
| D-16 | P2 | Cloud models/live voice/long-term companion chat | clear user demand, risk/cost controls | production architecture review |
| D-17 | P2 | Cross-device sync and accounts | demonstrated retained demand | identity, backup, deletion/security audit |

## Estimation (relative planning only)
**Lower complexity:** replacing demo prompt copy, basic capture/search UI, telemetry definitions. **Medium:** atomic datastore migration, search-source UX, multilingual recall test bench, privacy notices. **Higher:** reliable live speech, EventKit idempotency, secure sync and multi-tool agent. These categories are not delivery-time promises; engineering estimate requires first running the app and examining the code under Xcode.

## Risk register

| Risk | Consequence | Mitigation and stop condition |
|---|---|---|
| Low natural retrieval frequency | No ongoing value | Compare with Notes in 28-day pilot; pivot job if little retrieval |
| Hallucinated recall | Trust breach | Source-only candidate results; zero tolerance for unsourced confident assertions |
| Storage migration regression | Lost records | Transactional copy-read-verify-swap; never delete old until confirmed |
| Siri AI rapidly improving | Differentiation shrinks | Re-run competitor task comparison each meaningful release [S04] |
| Voice acquisition and use cost | Poor contribution | Treat as experimental add-on, quota scenario, no 'unlimited' |
| Character slows critical tasks | Higher abandonment | Focused state for useful tasks, reduced motion and no forced greetings |
| Privacy breach/analytics content | Trust, GDPR exposure | Local-first, content-free event schema, explicit consent and review [S17] |
| Pilot overfit to fans | False product-market evidence | Recruit fan and cold segment separately; preference test blinded |

## Do not cross the commercial release gate without
1. Reproducible secure persistence and correctly attributable retrieval; 2. consent and legal basis assessed; 3. observed external-user organic substitution and repeat; 4. documented voice/tool real-world behaviour, if included; 5. contribution economics from actual bills; 6. Apple platform policy and App Review assessment.
