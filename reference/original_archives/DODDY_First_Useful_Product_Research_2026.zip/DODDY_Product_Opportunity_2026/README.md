# DODDY — First Useful Product Experience
**October 8, 2026 | Research-backed decision pack v1.0**

## Executive decision
Candidate first job: **save a useful thought, retrieve it later accurately with original context.** Release a text-first private memory beta; make live voice and verified reminders independent follow-up experiments. **This is unvalidated product strategy, not proof of product-market fit.**

## Document index
- **A** `A_Consumer_AI_Opportunity_Research.md` — market, competition, 100-situation atlas, evidence limitations.
- **B** `B_Product_Direction_Evaluation.md` — 10 alternatives, all weighted scores, decision sensitivity.
- **C** `C_The_Doddy_Core_Experience.md` — primary job, five user journeys, 20 interactions.
- **D** `D_MVP_Product_Requirements.md` — scoped PRD, acceptance tests, instrumentation and exclusions.
- **E** `E_Technical_Feasibility_and_Repo_Audit.md` — connected GitHub repository inspection and iOS constraints.
- **F** `F_Retention_and_Behaviour_Strategy.md` — genuine repeated utility, North Star and 10 hypotheses.
- **G** `G_Validation_Programme.md` — interview questions, tests, 28-day study and decision gates.
- **H** `H_Commercial_Feasibility.md` — transparent subscription/AI cost scenario calculations.
- **I** `I_MVP_Build_Roadmap.md` — sequencing, priorities and risk gates.
- **J** `J_Executive_Product_Decision.md` — concise founder decision and answers to 25 mandatory questions.
- `SOURCES.md` — 28 source receipts, including public authorities and inspected private GitHub paths.
- `data/100_Opportunity_Atlas.csv` — full 100 original hypothetical situations with 16 research fields.
- `data/10_Direction_Weighted_Scores.csv` — inspectable scoring arithmetic.
- `data/20_Interaction_Test_Cases.csv` — sample UX, happy and failure paths.
- `data/10_Retention_Hypotheses.csv` — operational hypotheses and falsifiers.
- `data/Illustrative_Unit_Economics.csv` — 16 transparent scenarios, 100 to 100,000 registrations.
- `data/Build_Roadmap.csv` — milestone gates and implementation tasks.
- `DODDY_Product_Decision_Complete.pdf` — consolidated 33-page printable narrative.
- `DODDY_Product_Decision_Complete.md` — editable consolidated narrative.

## Evidence categories
**VERIFIED:** sourced current public product/API claim or fact found in the repo; **SUPPORTED HYPOTHESIS:** consistent with prior evidence, not proven for Doddy; **RECOMMENDATION:** explicit product judgement; **UNVALIDATED:** requires interviews, real participant observation or device QA. Everything labelled 'score', 'conversion', 'scenario', 'threshold', 'estimated effort' is an input to a test rather than a measurement.

## Limitations
No new Doddy participant field interviews, actual retention observations, physical iOS builds, direct billing records or live app performance measurements were performed. Current GitHub material was inspected via connected repository read operations; it was not modified. We avoided implying iOS side-button conversational-app access outside Japan.
