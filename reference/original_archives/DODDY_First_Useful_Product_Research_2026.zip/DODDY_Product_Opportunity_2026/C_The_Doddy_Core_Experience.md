# C — The First Useful Experience
**Product candidate:** “Tell it before you forget. Ask it when you need it.”

## Primary job-to-be-done
**When** I encounter a small useful detail I may need later, **I want** to save it instantly without categorising it, **so that** I can recover the exact information and its context when the need arises.

**Primary cohort:** Adults (18+) with iPhones who in the past 14 days have saved a thought in Notes, self-messages, screenshots or Reminders and later tried to find it. Recruit by behaviour, not demography or interest in AI.

**The two-part first value moment:** (1) a real note is durably saved and visibly verified; (2) the user later initiates a natural-language or keyword search and finds the right original note without a forced diary prompt. Part 2 is the meaningful differentiation test.

## Interaction contract
- **Entry:** one primary action, `Save thought`, and one equally visible secondary `Find something`. Text works immediately; App Shortcut is optional. No account wall.
- **Capture:** user's explicit save command only. Preserve verbatim accepted text and capture time/source; confirm only after durable write.
- **Retrieve:** search user records only. Show short extract, full source note, date when known, and edit status; offer alternatives/clear no-match. Never answer personal facts from model guesses.
- **Repair:** user edits existing item or clarifies ambiguous result; original preserved where reasonable. Deletion works without payment.
- **Personality:** Doddy may say “Got it” or “Found two—let's narrow it down”; no prolonged animated introduction or joke during task.

## Five full user journeys

### Journey 1 — Discovery from entertainment
**Motivation:** enjoys an episode featuring Doddy losing a recommendation. **Flow:** watches → sees that an interactive app exists → visits landing page → understands one specific promise → considers TestFlight invite → installs. **Permission:** none to browse page; in-app storage notice at first save. **Success:** accurately understands the product is user-directed capture/recall, not general phone omniscience. **Failure:** assumes it can read every message or already knows their life. **Measurement:** content variant → landing click, comprehension test, qualified install; report separate from actual recall.

### Journey 2 — First use, day 0
**Trigger:** participant has a real item they want to keep. **Flow:** open app → text 'Remember that the electrician recommended 6 mm anchors' → explicit save → persistence commit → visible saved item including source/date → user can view and edit. **Failure:** disk protected/full; show real error, retain draft. **Completion:** accepted text matches disk record after app restart. **Measurement:** real_save_persisted, latency, rejected_save, first_value_part1. Do not require microphone/sign-in/notification permissions.

### Journey 3 — Spontaneous day-after return
**Trigger:** user needs the saved information. **Flow:** open from icon/shortcut → 'What did I save about anchors?' → lexical matching → candidate record and exact snippet → participant confirms correct. **Failure:** no match or several near-matches; show those outcomes. **Completion:** human-verifiable successful lookup. **Measurement:** organic_recall_attempt, correct, wrong, uncertain, substitute_used; distinguish from prompted tutorial.

### Journey 4 — One-week use
**Trigger:** multiple notes accumulate. **Flow:** capture several topics without imposed organisation → find one with imperfect wording → correct one conflicting record → app displays original and edited versions. **Failure:** query outside lexical recall ability; request distinctive word, never hallucinate semantic match. **Completion:** repeated independent retrieval at low error. **Measurement:** unique users initiating 2+ organic recalls / all enrolled; per-user distribution; time versus Notes baseline.

### Journey 5 — One-month decision
**Trigger:** user chooses between Doddy and current capture tools. **Flow:** spontaneous saving and searching → in-product export/delete and control review → user reports concrete substitute cases → optional reminder prototype trial. **Failure:** captures accumulate without retrieval; user returns to Notes; no lock-in. **Completion:** demonstrated substitution, repeat success and self-described loss if app vanished. **Measurement:** D28 organic recall, cohort retention, source-checked wrong results, voluntary price test.

## 20 realistic interaction patterns
| ID | User says / situation | Correct response behaviour |
|---|---|---|
| C01 | Remember: Ola recommended the little ramen place near the station. | Saved exactly as written. |
| C02 | What restaurant did Ola mention? | Possible match: “Ola recommended the little ramen place near the station.” [Saved 8 Oct]. |
| C03 | Change that: it was a Vietnamese place, not ramen. | Here is the edited note; original wording remains viewable. |
| C04 | What is my passport number? | I can’t find that in what you saved here. |
| C05 | Which gift did I plan? | I found two gift ideas. Which person? |
| C06 | What size did I save for trousers? | I found two entries: size 34 and size 36. Here are the dates. |
| C07 | Remember I need to renew my passport. | Saved as a note. No reminder has been set. |
| C08 | Remind me about the passport next month. | I can save the intention, but I can’t create an Apple Reminder in this version. |
| C09 | Remember: | What would you like me to save? |
| C10 | Save this 6,000-character text. | That exceeds the limit. Please shorten it or split it. |
| C11 | What exact wording did I use about the holiday? | Here is the original entry. [View original]. |
| C12 | What did I save last Thursday? | I can search by phrase or show dated notes; date filtering is not yet supported. |
| C13 | Zapamiętaj, że do sernika potrzebuję twarogu. | Zapisane: „Do sernika potrzebuję twarogu”. |
| C14 | Co zapisałem o serniku? | Możliwy wynik: „Do sernika potrzebuję twarogu”. |
| C15 | Save that my order number is ABC-123. | Saved on this device. |
| C16 | Remember this now. | I can’t save while the data store is unavailable. Try after unlocking. |
| C17 | Delete everything I saved in Doddy. | This will remove your local records. Confirm deletion? |
| C18 | What did I save about cats? | I can’t find a personal note about that. Demo examples aren’t your memories. |
| C19 | Are you recording everything I say? | No. In this version I save only notes you explicitly ask to keep. |
| C20 | No, that’s not the recommendation I meant. | Got it. I’ll show other saved matches; I won’t overwrite anything unless you ask. |


## What is NOT a Doddy interaction in v1
“Book my dentist”, “scan my inbox”, “translate a meeting live”, “watch my screen”, “keep listening all day” and “decide what is important to remember automatically” cannot be represented as implemented features. Offer candid capabilities information or a narrow opt-in note capture instead.

## Product success and failure
A successful interaction must be **accurate, attributable, low effort, and verifiable**. Failures include wrong record, fake save, omitted filters, overbroad personal-context claim, unannounced sensitive capture, and slower-than-Notes performance. Character charm cannot compensate for any of these.
