# H — Commercial Feasibility & Unit Economics
**Warning:** Revenue and conversion figures below are deliberate, transparent **scenarios**, not predicted signups, customer demand, real provider bills, or a finished price proposal.

## Commercial hypothesis
A user who relies on memory retrieval may later pay for convenience such as cross-device sync, advanced retrieval, larger history or optional voice access. P0 capture, correction, retrieval, export and deletion should remain available during validation; do not charge to recover the user's own saved data.

## Inputs and assumptions
- Hypothetical consumer price **$8/month excluding applicable taxes**, no validated willingness to pay.
- Assumed store reduction **15%** yielding **$6.80 net receipts per payer**; 15% is only applicable under relevant terms and eligibility, with jurisdiction-specific differences [S20].
- Assumed **35% of registrations are monthly active**, **6% of monthly active are paying**. These are invented scenario knobs, not conversion benchmarks.
- Assumed nonvoice per payer monthly variable cost **$0.55** (infra/support/other inference combined); free active user variable cost **$0.06**. Not measured.
- **GPT-Live-1 $0.05 per minute**, billed per second, *front-end voice only*; backend model and tools are additional [S14]. Do not assume this is Doddy's eventual provider.
- Active base represented by registrations × 0.35; expected payers are fractional expected values for scenario math, not fractional real accounts.

## Monthly contribution under the assumptions
| Registrations | MAU assumption | Expected payers | Text-first monthly contribution | Regular voice (40 min) contribution | Heavy voice (216 min) contribution |
|---:|---:|---:|---:|---:|---:|
| 100 | 35 | 2.1 | $11 | $7 | $-12 |
| 1,000 | 350 | 21.0 | $112 | $70 | $-115 |
| 10,000 | 3,500 | 210.0 | $1,115 | $695 | $-1,153 |
| 100,000 | 35,000 | 2,100.0 | $11,151 | $6,951 | $-11,529 |


*Monthly contribution = expected payer net receipts − payer variable costs − free-MAU variable costs. It excludes VAT/sales tax, acquisition cost, developer salaries, legal expense, fixed platform spend and churn. The scenarios above can become very negative with heavy voice consumption.*

## Per-paying-user economics
| Voice use | Voice-only cost | Total estimated variable cost (incl $0.55) | Net receipts | Monthly contribution | Margin before fixed/CAC |
|---|---:|---:|---:|---:|---:|
| Text-first/no live voice | $0.00 | $0.55 | $6.80 | $6.25 | 91.9% |
| 7 minutes | $0.35 | $0.90 | $6.80 | $5.90 | 86.8% |
| 40 minutes | $2.00 | $2.55 | $6.80 | $4.25 | 62.5% |
| 216 minutes | $10.80 | $11.35 | $6.80 | -$4.55 | negative |

**At the sample rates:** approximately **29.8 live voice minutes** are affordable per payer at a 70% contribution-margin target before counting free users or fixed spend. Break-even at 125 minutes excludes free-user subsidies and omitted charges. Actual quota must be based on observed distribution and the complete billing stack.

## Commercial decision
Do **not** launch a general subscription on day one. Test revealed preference in the successfully retained cohort: real paid-offer clicks, then a transparent paid pilot if repeat value and costs support it. Suggested candidate $5 / $8 / $10 / $15 monthly anchors are *experiments* only; test pricing with tax-correct local presentation, store policies and cancellation rights. Early launch could reasonably be free and text-first while usefulness is assessed.

## Risks
Retention cost curve, iOS platform defaults, app-store acquisition expense, model price changes, support burden, users expecting 'unlimited', storage/data export liabilities and user reluctance to pay for a Notes alternative. Research [S03] reports weaker payer retention among AI subscription apps overall; do not assume a character removes the problem.

## Next measured inputs required
Organic saved items/user, eligible recall frequency, median provider-free core cost, storage growth, 95th percentile voice minutes, subscription paid conversion among users who obtained two actual outcomes, net receipts after actual fees/tax, CAC/organic share, churn by cohort. Calculate contribution using real invoices after pilot.
