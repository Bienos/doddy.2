---
title: "DODDY — First Useful Product Experience"
subtitle: "Research, Product Decision, MVP and Validation Programme"
author: "Product Research and Development"
date: "8 October 2026"
---

# Executive summary

**Decision:** Validate a narrow user-controlled capture-and-recall job before building an all-purpose voice companion. Research uses official product documentation, peer-reviewed and industry evidence and a read-only connected repository review. All customer behaviour, conversion and price hypotheses remain unvalidated.

**The outcome that matters:** A real user spontaneously returns to retrieve a previously saved item correctly and chooses Doddy over their previous method for that job.

**Package:** Documents A–J, 100-item research atlas, 10-direction scoring, 20 interaction examples, ten retention hypotheses, a 28-day pilot, an illustrative cost model and source register.


ewpage
# J — Executive Product Decision Memo
**To:** Doddy founder · **Date:** 8 October 2026 · **Decision:** Narrow first product, hold broader assistant ambitions

## Recommendation
**Build “Doddy Remembers” as a user-controlled capture-and-recall experience.** Target adult iPhone users who already keep useful details scattered across Notes, Reminders and messages to themselves. The first promise is not “I know everything about your life,” but **“Tell it before you forget. Ask it when you need it.”**

This is a **product recommendation**, not audience-validated positioning. The first release should test whether people prefer and return to a useful capture/recall flow. Doddy's character remains visible and recognisable but never obstructs task completion.

### One job / one outcome / two supporting capabilities
- **Primary job:** explicitly save a real thought and later retrieve the right original record.
- **Supporting capability 1:** fast text capture and optional existing App Shortcut access.
- **Supporting capability 2:** auditable, editable source-backed memory with honest ambiguity and miss handling.
- **First useful outcome:** an independently initiated **correct retrieval**; saving alone is not a sufficient win.
- **Secondary controlled experiment:** verified Apple Reminders follow-through for users who request it organically. Voice dictation is a feasibility/accessibility experiment, not a scope multiplier.

## Why this, not a Siri alternative?
Siri AI introduced deeper personal context, conversation and actions in September 2026 [S04]. ChatGPT has voice, memory and tasks [S10–S12], and Gemini offers task integration [S13]. A broader assistant would need to outperform entrenched platforms on integration and reliability. Doddy has a smaller wedge: intentionally captured, user-auditable memory without implicit data ingestion. Even that may fail against Apple Notes and the new Siri—so substitution is the critical test.

## Existing asset advantage and missing layers
The private repo contains a SwiftUI prototype, App Shortcuts, an explicit-memory model, local lexical recall and tests [S23–S27]. The live AI, microphone/speech and EventKit action paths are mocked, absent or unverified. Build reliable native memory UX and protected persistence first. Verify real physical-device operation; do not claim production readiness from scripted demos.

## No-go conditions
If 28-day organic use does not produce recurring retrieval and concrete substitution, or if a real head-to-head shows no effort/accuracy advantage over a user's incumbent tool, decline broad app development. If saved notes are lost, personal details are hallucinated confidently or privacy obligations cannot be satisfied, halt release regardless of apparent enthusiasm.

## Exact investment gate
Initial expense should fund a narrow technical core and **15–20 interviews → 12–16 comparator usability tests → 24–40-person, 28-day field pilot**. The 24-user directional gates in Document G require: safety conditions plus at least two of three behavioural tests (10 organic recallers by day 14; eight users achieving 2+ organic correct recalls by day 28; eight credible substitute users). Small denominators are transparent; do not extrapolate the figures to the market.

## Core business uncertainty
The $8-price and 6%-of-MAU payer scenario in Document H is illustrative only. At current published GPT-Live-1 front-end pricing, 216 minutes/month costs $10.80 per user before backend calls and overwhelms the sample net receipts [S14]. Therefore free text-first utility validation is economically safer than promising an unlimited speaking companion.

## 25 explicit product answers
**1. Initial audience**  Adult iPhone users already saving scattered small facts and recently needing to retrieve them; not everyone who likes Doddy.

**2. First problem**  Capturing a useful thought without filing work and recovering the exact record when needed.

**3. Frequency**  Unmeasured for the target cohort; plausible weekly with pockets of daily capture. Pilot establishes distributions.

**4. Current solution**  Notes, self-messages, reminders, screenshots and searching old chats.

**5. Current pain**  For some users context is scattered or lacks clear recall terms; must be verified, not assumed.

**6. Advantage**  Single quick capture; explicit originals, dates, edit history and honest no-match answers.

**7. Memory essential?**  Explicit saved records are essential. Autogenerated psychological or inferred user memory is not.

**8. Voice essential?**  No for core retention test. Optional access experiment after stable text baseline.

**9. Execution essential?**  Not in P0; an EventKit reminder is the strongest P1 alternative.

**10. Smallest scope**  Capture, durable store, source-linked search, edit/delete/export, fast entry and honest errors.

**11. Deliberate exclusions**  Live general AI chat as core, translation, broad agents, cross-app data ingestion, passive memory, sync.

**12. First meaningful outcome**  Later organic correct retrieval of a real previously saved note; first save is an earlier prerequisite.

**13. Return trigger**  A real need for saved information; not push prompting or streaks.

**14. Daily usage?**  Not required; weekly/episodic job may be viable if utility and economics justify it.

**15. Character effect**  Recognisable natural confirmation, low-friction help on error, no performance tax.

**16. Useful without character?**  Yes—text capture and search should outperform or complement Notes for selected users.

**17. iOS reality**  App Intents, Shortcuts, optional Back Tap/Action Button via user setup; no general Siri replacement in Poland.

**18. Prototype reuse**  SwiftUI shell, invocation router, local MemoryItem/AppState/RecallService; all need device QA.

**19. Unproven assumptions**  Frequency, substitution, cold-audience attraction, retention, pricing, iOS support edge cases.

**20. Cheapest disconfirming test**  Ask users to perform genuine capture/recall with their normal tool and Doddy; observe what they choose later.

**21. Abandon direction when**  After one targeted revision users do not independently recall or displace a workflow, or critical trust defects persist.

**22. Invest when**  Repeat independently verified retrieval, substitute displacement, safe storage and credible cost economics.

**23. What users pay for**  Unknown; may pay for reliable convenient cross-device and advanced retrieval, but needs actual paid test.

**24. Why prefer to ChatGPT/Siri?**  Only if its intentional memory UX proves faster, clearer and more trustworthy on actual tasks; not guaranteed.

**25. One exceptional ability**  Know precisely what I explicitly asked it to keep—and show it to me when needed, without making things up.


## Verdict
**VALIDATE THE NARROW MEMORY WEDGE; DO NOT YET BUILD THE BROAD COMPANION.** A measured increase in real-world retrieval success and recurring user-initiated substitution would justify the next layer. Otherwise use the character as entertainment IP and test a different single user job rather than accumulating arbitrary features.


# A — Consumer AI Opportunity Research
**Version 1.0 · 8 October 2026 · Decision research, not user validation**

## Question and comparison
Can Doddy displace an existing repeated consumer behavior with a more useful interaction? We consider adult iPhone users with a **demonstrated habit of capturing small useful thoughts** in Notes, Reminders, screenshots or messages to themselves. This is an initial recruitment hypothesis, not an asserted customer segment.

## Evidence ledger: what is established

| Observation | Implication for Doddy | Evidence status |
|---|---|---|
| 49% of US adults reported ever using AI chatbots; roughly one-quarter reported daily use (Pew Feb 2026). | Familiarity exists, but usage adoption does not demonstrate room for another assistant. | VERIFIED for surveyed US adults [S01] |
| Practical guidance, seeking information and writing were the largest ChatGPT conversation categories in research through July 2025. | General questions and writing are crowded; conversational usefulness is real. | VERIFIED for studied ChatGPT traffic, not all products [S02] |
| RevenueCat's 2026 subscription-app cohort shows AI apps with stronger payer monetisation yet weaker 12-month retention than non-AI. | Do not select a hook based on demos or short-term conversion alone. | VERIFIED for RevenueCat dataset, not Doddy [S03] |
| Apple announced Siri AI with personal context, systemwide actions, onscreen understanding and conversation in September 2026. English rollout is beta. | 'Siri but warmer' is fragile differentiation; test on compatible devices and markets. | VERIFIED announced capabilities, rollout varies [S04] |
| ChatGPT provides personal context, scheduled tasks and voice; Gemini supports connected reminders/tasks. | Memory, reminders and voice are features, not individually defensible moats. | VERIFIED documented feature families [S10-S13] |
| Research at CHI 2025 demonstrates personal recall over captured information can be technically difficult, with context and provenance important. | Traceable original capture and constrained retrieval should precede generated personal answers. | Research-supported engineering consideration, not market demand [S18] |

## Competitive substitution landscape

| Existing choice | Strength | Likely Doddy disadvantage | Potential experiment |
|---|---|---|---|
| Apple Notes | Free, familiar, sync/search, native | User already has it; Doddy adds friction if recall isn't materially better | Capture a thought then find it later, time and error comparison |
| Apple Reminders | Reliable native triggers, Siri/OS integrated | Doddy cannot beat it at basic reminder reliability without integration | Test intent capture / follow-through only after recall succeeds |
| Siri AI | Deep OS context and controls on supported devices | Third-party OS integration is weaker; access may be slower | Narrow source-auditable user-selected memory; compare on iOS 27 |
| ChatGPT | Strong general chat, voice, memory, tasks | User may already pay; duplicating it has low value | Blind preference test on explicit saved-item retrieval |
| Gemini | Tasks, search, Google context, voice on supported products | Large connected ecosystem | Do not replicate generic tasks |
| Perplexity / search | Broad information retrieval | Doddy cannot compete on general search breadth initially | Focus on user-saved private context rather than world facts |
| Replika / Character.AI | Engaging personality or roleplay | Companionship does not establish practical task utility | Character-only versus utility-only condition |
| Self-messages / screenshots | Capture with essentially zero learning cost | Doddy needs improved later retrieval without privacy creep | Measure genuine workflow substitution |
| Personal task apps | Mature notifications and status tracking | Replacing them requires consistency and integration | Only pursue after repeated user-initiated demand |

**Critical competitive update:** In September 2026, Siri AI entered English beta with more capable personal context and app actions [S04]. Future Doddy differentiation must remain compelling on compatible devices; temporary regional or language gaps are not a durable moat.

## Opportunity atlas: 100 situations
The accompanying `data/100_Opportunity_Atlas.csv` contains **100 individually defined hypothetical jobs**, each labelled by trigger, existing substitute, friction, frequency, context required, input route, intended result, risk and technical feasibility. These are *research hypotheses*, not interviews or observed demand. Coverage is ten domains with ten situations each: capture/recall, personal administration, relationships, shopping, travel, projects, study, planning, home and communication.

**High-priority jobs to test first** are saving a thought without choosing a folder; finding the exact recommendation someone mentioned; recovering the latest version of an explicitly saved decision; finding a warranty/return detail; and retrieving an idea captured while occupied. Low-priority jobs include broad research, arbitrary autonomous actions, background monitoring, and tasks already solved well by native reminders.

## Ranked behavioural job clusters

| Cluster | Repeat hypothesis | Friction | Dominant alternative | MVP suitability |
|---|---|---|---|---|
| Capture small facts / later retrieve | Often weekly, sometimes daily; must measure | Information scattered across applications and contexts | Notes, search, self-messaging | Highest: text-first, private, bounded |
| Complete follow-through after an intention | Frequently useful but failure stakes higher | Intent is expressed but action never completed | Reminders, calendars, habit tools | Medium: EventKit test after stable core |
| Voice question while hands occupied | Depends on setting and social comfort | Unlock, find app, type | Siri AI, ChatGPT Voice | Medium: access/latency differentiator unproven |
| Plan tasks across calendars/apps | Potentially daily for some | Fragmented tasks | Siri, calendars, work tools | Low: permissions/integrations heavy |
| Real-time translation | Situational and high-value for travellers | Turn-taking and language friction | System translation, Gemini/ChatGPT | Alternative experiment, not primary |
| Entertainment chat | Could be frequent without solving jobs | Novelty decay, substitution uncertainty | Character.AI, social media | Separate acquisition strategy; no assumed utility |

## Research gaps and source limitations
No participant interviews, field observation, retention measurements or head-to-head comparison has been performed for this report. US adoption data cannot infer Polish or EU preferences; RevenueCat subscription cohorts differ from a free-first character app; repository tests do not establish human recall usability; private notes contain sensitive material even if stored locally. Self-selection into a Doddy fan audience could inflate affinity and mask weak product need.

**Next step:** recruit people based on a *recent concrete instance* of losing, searching for or remembering a useful detail—not enthusiasm for Doddy or AI.

See [SOURCES.md](SOURCES.md) for clickable evidence references.


# B — Ten Product Directions and Decision Matrix
**All numerical ratings are editorial estimates (1–5), not measured user preference or validated market forecasts.**

## Decision rule
Choose a **single repeatable job** with testable substitution and feasible first delivery. Score 1 (weak) to 5 (strong); weighted average uses explicit weights and no hidden adjustment. See `data/10_Direction_Weighted_Scores.csv` for every raw score.

| Criterion | Weight | Criterion | Weight |
|---|---:|---|---:|
| Problem severity | 18% | Repeat potential | 15% |
| Differentiation | 15% | Perceived value | 12% |
| MVP feasibility | 10% | Reliability | 10% |
| Low friction | 8% | Monetisation | 5% |
| Character fit | 4% | Sustainability | 3% |

| Rank | Direction | Weighted score / 5 | Weakest assumption |
|---:|---|---:|---|
| 1 | A · Explicit memory | 3.99 | Users may save but never retrieve |
| 2 | C · Follow-through | 3.76 | Reliability and permission complexity |
| 3 | I · General agent | 3.55 | Large scope, frequent tool failures |
| 4 | H · Learning | 3.48 | Mature tutors already available |
| 5 | G · Day planner | 3.47 | Calendar access and incumbent integration |
| 6 | B · Voice-first access | 3.33 | Siri/ChatGPT already solve it |
| 7 | F · Problem solver | 3.32 | No distinctive job or retrieval moat |
| 8 | E · Translation | 3.19 | Situational; strong native alternatives |
| 9 | D · Context agent | 3.16 | Requires broad sensitive data |
| 10 | J · Open-ended mate | 3.13 | Entertainment mistaken for utility |


## Ten competing hypotheses, genuinely different MVPs

| Direction | Narrow audience and primary job | Smallest demonstration | Central failure risk |
|---|---|---|---|
| A: Explicit memory | People saving scattered details | Save one statement, retrieve with source later | Never return for recall; Notes is enough |
| B: Voice-first access | People who often cannot type | Invoke, ask, hear answer quickly | System voice assistant access is faster |
| C: Follow-through | People who forget action commitments | Translate explicit intention into verified reminder | Too similar to Siri; action failure destroys trust |
| D: Personal-context agent | Heavy AI users seeking continuity | One connected data source, contextual answer | Privacy/trust overhead; Siri/ChatGPT incumbent |
| E: Translation | Bilingual travellers / families | Low-latency two-way turn exchange | Occasional travel use, language accuracy stakes |
| F: Problem solver | People facing small practical problems | Quick guided answer to known high-frequency task | Generic ChatGPT or search wins |
| G: Day planner | Calendar-heavy users | View and reorganise one day's commitments | Calendar privacy + mature native alternatives |
| H: Learning | Self-directed learners | Repeat one explanation with understanding check | Numerous specialist tutors, low differentiation |
| I: Autonomous agent | Users delegating multi-app tasks | Verified multi-step action with confirmation | API scope, unreliability, operational cost |
| J: Open-ended mate | Entertainment-first character fans | Pleasant chat with gentle assistance | Novelty, attachment risk, weak willingness to pay |

## Decision and bounded combination
**Primary job:** capture an explicitly saved useful thought and find its original information later. **Supporting 1:** low-friction text entry + optional existing Shortcut. **Supporting 2:** provenance and user correction/deletion controls. **Secondary experiment:** verified Apple Reminder creation *after* recall succeeds and users request it repeatedly. Real conversational voice remains a parallel feasibility experiment, not a release blocker for the memory-value test.

The first outcome includes **two separate moments**: capture successfully persisted now and independent later retrieval. No 'activation' based only on talking with Doddy.

## Challenges to the winner
A high composite score is not market proof. Memory may lose for three reasons: (1) retrieval opportunities may be too infrequent; (2) Notes/Siri search may already be good enough; (3) people may not trust putting personal details into a new product. The app must measure repeated source-backed recall and substitution directly. A feature called 'memory' is not differentiated if ChatGPT, Apple and Google can remember too [S04,S10,S13].

## Sensitivity / decision reversal tests
- If the chosen cohort reports **almost no retrieval**, A's repetition and value assumptions decline; C or a narrower segment may win.
- If protected persistence proves difficult, A's feasibility score falls and confidence must drop; no 'saved' confirmation without durable write.
- If Siri AI on compatible phones matches Doddy's full save/retrieve flow at equal effort, A's differentiation score should approach 1–2 and the product should pivot/stop.
- If user-initiated recurring reminders vastly exceed retrieval attempts, test C in its own controlled experiment rather than silently adding ten integrations.
- Different weight choices can reorder A/C/I; this matrix is a transparent prioritisation exercise, **not objective proof**.

## Hard exclusions for v1
No open-ended autonomous agent; no broad connected-app ingestion; no calendar/email/contacts scraping; no passive memory from every conversation; no always-on microphone; no full-screen ambient overlay; no character-driven push notifications; no complex social feeds or gamification; no paid memory extraction lock-in.


# C — The First Useful Experience
**Product candidate:** “Tell it before you forget. Ask it when you need it.”

## Primary job-to-be-done
**When** I encounter a small useful detail I may need later, **I want** to save it instantly without categorising it, **so that** I can recover the exact information and its context when the need arises.

**Primary cohort:** Adults (18+) with iPhones who in the past 14 days have saved a thought in Notes, self-messages, screenshots or Reminders and later tried to find it. Recruit by behaviour, not demography or interest in AI.

**The two-part first value moment:** (1) a real note is durably saved and visibly verified; (2) the user later initiates a natural-language or keyword search and finds the right original note without a forced diary prompt. Part 2 is the meaningful differentiation test.

## Interaction contract
- **Entry:** one primary action, `Save thought`, and one equally visible secondary `Find something`. Text works immediately; App Shortcut is optional. No account wall.
- **Capture:** user's explicit save command only. Preserve verbatim accepted text and capture time/source; confirm only after durable write.
- **Retrieve:** search user records only. Show short extract, full source note, date when known, and edit status; offer alternatives/clear no-match. Never answer personal facts from model guesses.
- **Repair:** user edits existing item or clarifies ambiguous result; original preserved where reasonable. Deletion works without payment.
- **Personality:** Doddy may say “Got it” or “Found two—let's narrow it down”; no prolonged animated introduction or joke during task.

## Five full user journeys

### Journey 1 — Discovery from entertainment
**Motivation:** enjoys an episode featuring Doddy losing a recommendation. **Flow:** watches → sees that an interactive app exists → visits landing page → understands one specific promise → considers TestFlight invite → installs. **Permission:** none to browse page; in-app storage notice at first save. **Success:** accurately understands the product is user-directed capture/recall, not general phone omniscience. **Failure:** assumes it can read every message or already knows their life. **Measurement:** content variant → landing click, comprehension test, qualified install; report separate from actual recall.

### Journey 2 — First use, day 0
**Trigger:** participant has a real item they want to keep. **Flow:** open app → text 'Remember that the electrician recommended 6 mm anchors' → explicit save → persistence commit → visible saved item including source/date → user can view and edit. **Failure:** disk protected/full; show real error, retain draft. **Completion:** accepted text matches disk record after app restart. **Measurement:** real_save_persisted, latency, rejected_save, first_value_part1. Do not require microphone/sign-in/notification permissions.

### Journey 3 — Spontaneous day-after return
**Trigger:** user needs the saved information. **Flow:** open from icon/shortcut → 'What did I save about anchors?' → lexical matching → candidate record and exact snippet → participant confirms correct. **Failure:** no match or several near-matches; show those outcomes. **Completion:** human-verifiable successful lookup. **Measurement:** organic_recall_attempt, correct, wrong, uncertain, substitute_used; distinguish from prompted tutorial.

### Journey 4 — One-week use
**Trigger:** multiple notes accumulate. **Flow:** capture several topics without imposed organisation → find one with imperfect wording → correct one conflicting record → app displays original and edited versions. **Failure:** query outside lexical recall ability; request distinctive word, never hallucinate semantic match. **Completion:** repeated independent retrieval at low error. **Measurement:** unique users initiating 2+ organic recalls / all enrolled; per-user distribution; time versus Notes baseline.

### Journey 5 — One-month decision
**Trigger:** user chooses between Doddy and current capture tools. **Flow:** spontaneous saving and searching → in-product export/delete and control review → user reports concrete substitute cases → optional reminder prototype trial. **Failure:** captures accumulate without retrieval; user returns to Notes; no lock-in. **Completion:** demonstrated substitution, repeat success and self-described loss if app vanished. **Measurement:** D28 organic recall, cohort retention, source-checked wrong results, voluntary price test.

## 20 realistic interaction patterns
| ID | User says / situation | Correct response behaviour |
|---|---|---|
| C01 | Remember: Ola recommended the little ramen place near the station. | Saved exactly as written. |
| C02 | What restaurant did Ola mention? | Possible match: “Ola recommended the little ramen place near the station.” [Saved 8 Oct]. |
| C03 | Change that: it was a Vietnamese place, not ramen. | Here is the edited note; original wording remains viewable. |
| C04 | What is my passport number? | I can’t find that in what you saved here. |
| C05 | Which gift did I plan? | I found two gift ideas. Which person? |
| C06 | What size did I save for trousers? | I found two entries: size 34 and size 36. Here are the dates. |
| C07 | Remember I need to renew my passport. | Saved as a note. No reminder has been set. |
| C08 | Remind me about the passport next month. | I can save the intention, but I can’t create an Apple Reminder in this version. |
| C09 | Remember: | What would you like me to save? |
| C10 | Save this 6,000-character text. | That exceeds the limit. Please shorten it or split it. |
| C11 | What exact wording did I use about the holiday? | Here is the original entry. [View original]. |
| C12 | What did I save last Thursday? | I can search by phrase or show dated notes; date filtering is not yet supported. |
| C13 | Zapamiętaj, że do sernika potrzebuję twarogu. | Zapisane: „Do sernika potrzebuję twarogu”. |
| C14 | Co zapisałem o serniku? | Możliwy wynik: „Do sernika potrzebuję twarogu”. |
| C15 | Save that my order number is ABC-123. | Saved on this device. |
| C16 | Remember this now. | I can’t save while the data store is unavailable. Try after unlocking. |
| C17 | Delete everything I saved in Doddy. | This will remove your local records. Confirm deletion? |
| C18 | What did I save about cats? | I can’t find a personal note about that. Demo examples aren’t your memories. |
| C19 | Are you recording everything I say? | No. In this version I save only notes you explicitly ask to keep. |
| C20 | No, that’s not the recommendation I meant. | Got it. I’ll show other saved matches; I won’t overwrite anything unless you ask. |


## What is NOT a Doddy interaction in v1
“Book my dentist”, “scan my inbox”, “translate a meeting live”, “watch my screen”, “keep listening all day” and “decide what is important to remember automatically” cannot be represented as implemented features. Offer candid capabilities information or a narrow opt-in note capture instead.

## Product success and failure
A successful interaction must be **accurate, attributable, low effort, and verifiable**. Failures include wrong record, fake save, omitted filters, overbroad personal-context claim, unannounced sensitive capture, and slower-than-Notes performance. Character charm cannot compensate for any of these.


# D — MVP Product Requirements Document (PRD)
**Status:** recommended for validation; not an approved product baseline. **Target platform:** iPhone, initial compatibility iOS 17+ subject to Xcode/device testing. **North-star job:** explicit save → later correct recall.

## Scope locked for first external text beta

| ID | Priority | Feature | Business rule | Acceptance criterion |
|---|---|---|---|---|
| P0-01 | P0 | Zero-account first use | Start without external provider login | New install saves own note with no demo login selection |
| P0-02 | P0 | Explicit text capture | Only `Save` or clear intent writes | No passive extraction; content copied exactly |
| P0-03 | P0 | Protected reliable storage | Atomic, throwing local persistence | Cold-restart readback matches committed item; errors visible |
| P0-04 | P0 | Capture provenance | Date (if known), input source, original text, current text | Legacy unknown stays unknown; no fabricated timestamps |
| P0-05 | P0 | Candidate recall | Exact/normalized terms, bounded fuzzy; records only | Correct candidate IDs; explicit miss/ambiguity and unsupported constraints |
| P0-06 | P0 | Source display | Quote original note; show edit flag | Response source links back to stored record |
| P0-07 | P0 | Correction / delete / export | User controls saved content | Edits persist; deletion confirmed; export usable offline |
| P0-08 | P0 | Fail-safe UX | No false action success | Disk full, locked store and corrupt migration not reported as saved |
| P0-09 | P0 | Text input and accessibility | Voice not necessary | Full flow via keyboard, VoiceOver, Dynamic Type and reduced motion |
| P0-10 | P0 | Privacy and safety baseline | Adult participants; no hidden analysis | Clear explanation; data-minimal content-free telemetry opt-in |
| P1-01 | P1 | Foreground voice dictation | Permissioned real capture on device | Real audio measured; transcript correction and text fallback |
| P1-02 | P1 | Verified Apple Reminder | Explicit request, resolved date, EventKit success | External ID persisted; retries idempotent; denied permission honest |
| P1-03 | P1 | Control Center / advanced quick access | Supported OS and extension | Device tested; no default Back Tap configuration claim |
| P1-04 | P1 | Semantic recall | Source-grounded paraphrase over candidates | Human-labeled multilingual evaluation beats lexical baseline safely |
| P2-01 | P2 | Live speech conversation | Full audio loop and voice UX | Meaningful use warrants measured costs and latency |
| P2-02 | P2 | Sync and account identity | Opt-in multi-device | Threat model, backup, export/delete, isolation checked |
| P2-03 | P2 | Calendar/email/other actions | Only after observed demand | Individual permission/reliability gate per action |
| EX-01 | Excluded | Always-on listener, autonomous app operator, generic screen overlay, character-driven daily notifications | Not a credible MVP | Remain absent |

## Core functional user stories
**US-01:** As a user with a useful thought, I can save an explicit record so I don't have to choose a folder. **Given** nonempty text <= 5,000 characters **when** I tap Save **then** the app durably commits it and shows exactly what was accepted; **if** commit fails, it retains a recoverable draft and never says 'Saved'.

**US-02:** As a returning user, I can retrieve a record using distinctive words. **Given** saved notes **when** I search **then** the app returns relevant stored items and timestamps, not inferred facts; unsupported temporal filters are explicitly called out.

**US-03:** As a user with two similar items, I can choose among them. **Given** ambiguous matches **when** I query **then** at least two options and provenance are presented; no single unsupported answer is asserted.

**US-04:** As a user correcting a note, I can edit or delete it without losing control. **Given** saved record **when** I edit **then** current text changes, original is preserved with edited status; when deleting, actual persisted record is gone after restart.

**US-05:** As a user with a constrained device or poor connectivity, I can still use text capture and find my local notes; no network call is required for the core flow. **Given** offline mode **when** I save and search **then** reliable local results are available subject to OS data protection.

**US-06:** As a cautious user, I can understand what is retained and turn analytics off. **Given** first save **when** disclosure appears **then** it is concise, accurate and separate from any optional instrumentation permission.

## Data model (conceptual, verify against the repo)
`MemoryItem { id: UUID, rawText: String, text: String, createdAt?: Date, updatedAt?: Date, source: enum, edited: Bool }`. Add explicit storage schema version and tombstone/migration markers before production; no new person graph or embedding store required. Query result `RecallResult {{ query, status: found|ambiguous|miss|unsupported_constraint, candidateIDs: [UUID], reasonCode }`. Do not use model-generated confidence as a probability.

## State transitions and invariants
`DRAFT → VALIDATED → WRITE_PENDING → SAVED | FAILED`. Only `SAVED` shows completion. `SEARCHING → MATCHES | MISS | NEEDS_DETAIL | FAILURE`. Never cross from model text to native action without validated typed arguments and explicit user authorisation. A model may select candidate IDs from a supplied bounded set, but may not invent IDs or mutate notes without a clear user request.

## Non-functional quality gates (engineering targets, not achieved performance)
- **P0 local save:** target p95 ≤ 300 ms on test devices for ordinary notes; display committed state only after durable acknowledgment. Measure slower-device tail.
- **Local exact search:** target p95 ≤ 500 ms for <= 2,000 notes on supported devices; test memory pressure and diacritics.
- **Crash integrity:** zero lost acknowledged records in restart/kill/storage test suite. Any confirmed acknowledged loss blocks release.
- **Wrong confident personal fact:** zero in labelled high-risk regression suite; in user studies report per-denominator error rather than broad guarantees.
- **Availability:** local text search works offline; voice services optional and must report unsupported language/permission states.
- **Accessibility:** no motion or spoken output required to finish the task.

## Analytics event contract
Use a predefined event schema with `event_name, anonymous_trial_id, session_id, timestamp, build_version, onboarding_or_organic, duration_bucket, outcome_code`; prohibit transcripts, note content, names, URLs, message body, precise geolocation or arbitrary diagnostic text. Events: `first_save_attempted`, `save_persisted`, `save_failed`, `organic_recall_attempted`, `recall_correct_confirmed`, `recall_wrong_confirmed`, `recall_uncertain`, `edit_saved`, `delete_confirmed`, `quick_access_invoked`, `reminder_action_verified` (P1). Publish event definitions before testing.

## Explicit permissions and ethics
Core P0 requires no microphone, contacts, calendar or notification permission. Local data storage must have a tested file-protection and backup policy. Users should inspect, correct, export and delete active records. Age-gate validation participants 18+ until youth-specific safety and legal review. GDPR lawful basis, privacy notice, retention and processor review are release requirements [S17].

## Definition of done
A participant can independently save a real note, force-close/restart, retrieve original text, identify ambiguous results, correct/delete/export notes, work offline, decline all optional permissions, and receive true errors when storage is unavailable. Tests run on actual iPhones; code presence or simulation does not satisfy this gate.


# E — Technical Feasibility and Current Repository Audit
**Repository inspected with connected GitHub access on 8 October 2026:** [`Bienos/AI-AGENT-DODDY`](https://github.com/Bienos/AI-AGENT-DODDY) (`main`). This is a **document and code-path inventory**, not a fresh local Xcode build or penetration test. README/product spec/feature matrix/engineering/backlog read; device behaviour unverified.

## What exists versus what does not

| Component | Current implementation status, per repository | Next required proof |
|---|---|---|
| SwiftUI iPhone prototype | Existing `Companion.xcodeproj`, iOS 17+ target | Build, simulator and physical device test |
| Conversational controller | Scripted questions/answers and mocked listening | Connect provider with cancellation/stale result tests |
| Shortcuts invocation | `TalkToCompanionIntent`, invocation router in source | Test actual Shortcut, cold start, signed-out experience |
| Back Tap | Documented manual setup | User config + physical device tests; app cannot assign automatically |
| Local memory | `MemoryItem`, `AppState`, original/edit text, source metadata | Native memory UI wiring and protected storage upgrade |
| Local recall | `LocalRecallService` lexical/fuzzy candidate retrieval | Real participant retrieval accuracy, Polish inflection and natural paraphrases |
| Memory tests | README states 33 tests + synthetic 50 records/100 queries | Independently execute current suite and inspect failures |
| Persistence | UserDefaults JSON | Replace with atomic protected throwing store |
| Voice/audio | **Mock only**; no real mic or playback | Foreground permission, audio, interruptions and transcripts |
| AI | **Mock only**, no live provider or key broker | Product need and secure inference architecture first |
| Apple Reminders | **Not implemented** | Typed proposal, EventKit permission, verified write |
| Account | Demo local provider choice only | Remove demo wall for beta or implement real auth after need |
| Control Center / Island | Browser showcase/planned; no native service | Extension/ActivityKit feasibility separately |
| Analytics | Schema/specification only | Content-free opt-in implementation and consent audit |

Repo source references: [S23–S28]. The referenced `docs/product/VERIFICATION.md` was not retrievable at the exact path during this review, so the reported test execution and native QA could not be independently verified.

## Recommended minimal architecture
`SwiftUI capture/search UI → validated domain operations → MemoryStore (transactional, file protected) → LocalRecallService → source-linked result`. Keep local domain layer free from cloud model dependencies for the first utility validation. Replace UserDefaults with one well-tested option (SQLite/GRDB, SwiftData or atomic protected local file); choose based on required query/index size and migration guarantees, not architectural fashion. SQLite FTS5 can be introduced when lexical performance justifies it.

**P0 requires no cloud model.** Doddy's persona can appear in product copy, light reaction and confirmations without hallucinated chat. The live companion architecture should remain modular behind `AIService` and `SpeechService`, then be introduced after baseline utility evidence.

## Voice technology and honest constraints
- `SpeechAnalyzer` / `SpeechTranscriber` offers a speech-to-text route with supported runtime assets; check language availability, OS versions and physical-device behaviour. Older `SFSpeechRecognizer` can involve server processing and requires distinct disclosure [S15–S16].
- Apple permits App Intents / Shortcuts; users configure Back Tap in Accessibility settings; applicable Action Buttons are manually assigned [S06–S08].
- Controls can appear in supported Control Center/Lock Screen contexts, but an interactive Control does not grant permission to record arbitrary background audio or inspect all app content [S08,S21].
- Apple's third-party conversational **side-button replacement** feature is documented for iPhone **in Japan** with entitlement and region requirements. Do not sell it as a Poland/EU feature [S09].
- Dynamic Island / Live Activities should represent a genuinely ongoing user-permitted activity, not an always-running animated pet or fake assistant progress indicator.
- Apps cannot programmatically assign their own Back Tap setting by default [S06].

## EventKit follow-through contract (P1 only)
`intent → propose {operationId,title,dueDate,tz} → clarify dates → request explicit permission → persist pending operation → EventKit save → reconcile external ID → show success`. EventKit asks for full Reminders access, while Calendar permissions include write-only event access options; do not conflate them [S05]. If denied, offer an unscheduled saved note without claiming a reminder exists. Timezone/daylight saving, interrupted writes, duplicate retries and deletion/undo require device tests.

## Failure model
| Failure | UX behaviour | Engineering check |
|---|---|---|
| disk full/protection lock | Do not claim save; preserve draft | fault-injected store write |
| corrupted previous data | Preserve raw unreadable bytes; offer recovery | migration rollback test |
| no recall match | Explicit miss, show source search suggestions | curated miss corpus |
| conflicting notes | Show originals/dates, ask | conflict fixture |
| unsupported time filter | State limitation; no dropped constraint | date-expression fixture |
| voice permission denied | Text is fully functional | permission denial device test |
| background interruption | Stop audio and prevent stale completion | lifecycle harness + device |
| external reminder ambiguous | Confirm before writing | timezone/relative time cases |

## Privacy/security boundaries
For P0, no contact/email/photos access. Records are personal data and may be sensitive. Secure local file permissions, protected storage, minimise analytics, ensure deletion/export, document backups and provider boundaries if later introduced. Local-first is **not** GDPR exemption [S17]. Threat model: device theft, backup leakage, data migration errors, malicious shared strings (if Share Sheet added), prompt injection through retrieved text (if LLM enabled later), and accidental logs.

## Engineering gate sequence
1. Run repository's existing Swift tests and Xcode build; record exact SHA/device/OS. 2. Replace demo storage transactionally. 3. Connect minimal native UI. 4. Verify capture/recall against labelled real queries. 5. Add opt-in analytics. 6. Ship controlled text beta. 7. Only then implement and test voice/EventKit modules separately.


# F — Retention, Activation and Responsible Engagement
**No observed Doddy cohorts exist in this report.** Targets below are proposed decision heuristics, not industry norms.

## Primary metric
**Weekly users with at least one independently verified, organic correct retrieval**, divided by all eligible enrolled users for the corresponding cohort. This captures the delayed outcome, not just note accumulation. Because recall is episodic, also report **28-day meaningful outcome retention** and time-to-next-natural-need. A daily streak is the wrong North Star.

**Metric tree:** eligible enrolled → first real save → later organic recall attempt → correct adjudicated recall → displaced alternative workflow → second organic correct recall → willingness to keep/use/pay. Guardrails: confirmed-wrong results, false save success, privacy complaints, time-to-value, error rate, disable/delete requests.

## Denominators and interpretations
- `Activation`: first real saved record persisted and verified / all qualified installations. Do **not** confuse with two-step memory utility.
- `Delayed utility conversion`: at least one independently initiated and adjudicated correct retrieval within 14 days / all qualified installations.
- `D1, D7, D30 return`: any organic session on exact local day among installed users, including zeros; report separately from task-success retention.
- `W1/W2 meaningful user`: >=1 organic correct recall in each interval / all originally eligible users; reports with n counts and missing classifications.
- `Recall precision`: correct targeted source among adjudicated responses / adjudicated source responses; uncertain and unjudged not silently counted correct.
- `Confirmed-wrong confident rate`: incorrect assertive matches / assertive matches independently adjudicated. One harmful high-confidence wrong claim is investigated.
- `Substitution`: sampled sessions where participant would otherwise use another tool and Doddy completed the same job / answered sampled sessions; disclose response bias.
- `Quick access value`: net task effort, cold/warm invocation time, successful completion; never infer from shortcut activation count alone.

## Ten testable retention hypotheses
| ID | Hypothesis | Test / directional target | Falsifier |
|---|---|---|---|
| H01 | Recent Notes/self-message users will try explicit capture | Observe 3+ captures during 14 days without reminders | <20% capture twice organically |
| H02 | Later retrieval is a meaningful job | ≥40% enrolled initiate ≥1 spontaneous recall by day 14 | <20% initiate any recall |
| H03 | Visible sources improve trust | Participants correctly identify record provenance ≥90% in tasks | Source display ignored or causes confusion |
| H04 | One entry point can replace self-message | ≥30% of respondent substitution samples name a displaced tool | <10% report substitution |
| H05 | Text beats microphone in shared spaces | Diary shows voice avoided in shared settings; A/B preference | Voice strongly preferred across contexts |
| H06 | Voice enhances capture while moving | 20%+ task-time reduction in observed hands-busy conditions | High error / permission drop-off |
| H07 | Character adds approachability without slowing use | No meaningful increase in completion time; preference split by fan/nonfan | Cute reactions frustrate time-pressed users |
| H08 | Saved originals outperform auto-inferred memories in trust | Fewer wrong-confident answers and higher source confidence than generative baseline | Recall misses too many paraphrases |
| H09 | Native reminders are a demanded next job | ≥25% retained users spontaneously ask for confirmed action | <10% ask after 28 days |
| H10 | Users will pay only after seeing retrieval value | Some users complete real paid test after seeing repeat value | Only survey stated preference; no paid conversion |


## Natural return triggers
An independent need for a saved recommendation, a product detail, a question to ask later, an earlier project decision, or a voluntarily initiated retrieval. Capture alone may become a daily pattern for some people but is not proof that the saved content is useful. Notifications should only reflect explicit user-requested tasks; no 'I miss you', personal guilt or spontaneous emotional checking-in.

## Character contribution experiment
Randomise on first-use demo into **utility-neutral confirmation** (“Saved”) versus **restrained character voice** (“Got it. Saved exactly like that.”), keeping storage/retrieval identical. Blind follow-up with unfamiliar users and existing character fans separately. Measure comfort, comprehension and speed; do not use total conversation minutes as a success proxy.

## Personalisation boundaries
Personal memory is user-selected content. Do not automatically transform every chat into durable facts. No inferential profiling, private relationship predictions or hidden cross-app indexing. Context references only when directly relevant and sourced. 'Mate' describes tone and access, not emotional dependence or reciprocity. Adult-only pilot; no engagement optimisation targeted at loneliness [S19].

## Research validity safeguards
Separate onboarding tutorials, staff prompts, notification-triggered traffic, content fans and organic return. Do not remove inactive participants from denominators. Report median and individual range (not only aggregate average), device/OS capability and whether alternatives were available. Do not benchmark exploratory pilot percentages as population retention.


# G — Validation Programme and Decision Gates
**Goal:** decide whether Doddy solves a real recurring job better than alternatives. Tests are NOT claimed executed. Suggested total programme: discovery (2 weeks), controlled tasks (1 week), organic-use pilot (28 days), then pricing exploration if gates pass.

## Research arms and samples

| Stage | Proposed sample | Method | Critical decision |
|---|---|---|---|
| 1 Problem interviews | 15–20 adults, screened by a last-14-days example | 30–45min jobs interviews; no pitch for first half | Is failed retrieval frequent/painful enough? |
| 2 Concept test | 40–60 mixed fan/nonfan respondents | Randomised one-job propositions + comprehension | Is capture/recall understood and credible? |
| 3 Comparator usability | 12–16 participants, within-subject cross-over | Same 5 authentic retrieval tasks in Notes/Siri/ChatGPT and Doddy, counterbalanced | Faster and more accurate at comparable effort? |
| 4 Naturalistic pilot | 24–40 qualified adult iPhone users | 28-day TestFlight, no prompted daily engagement | Is there spontaneous save→recall, substitution, repeat? |
| 5 Price test | only users who achieved repeat utility | Offer actual terms / optional paid beta if operationally ready | Any revealed willingness to pay? |

These samples yield directional qualitative signals, not reliable population conversion rates. Use binomial confidence intervals for proportions and explicitly state uncertainty. Randomisation balances order, not demographics or product enthusiasm.

## Screener — must establish past behaviour
Ask for a non-sensitive recent example of saving something you hoped to find later. Where did they put it, when did they need it, how did they search, how long did it take, did they succeed, and why not use Notes/Reminders? Exclude people without a real recent capture habit from the primary cohort; recruit them separately for discoverability testing. Do not demand screenshots of private records.

## Interview protocol (first 12 questions without Doddy pitch)
1. Tell me about the last time you saved a detail for later. 2. Why did it matter? 3. Where did you put it? 4. Show only non-sensitive workflow steps, not private contents. 5. What did you expect to remember? 6. When did you look again? 7. Did you recover it? 8. How much effort did that take? 9. What made the current method good enough? 10. What information would you refuse to put in a new app? 11. What happened the last time a reminder failed? 12. Would a faster retrieval process change anything important? Only then expose unbranded concepts and ask for unaided explanation.

## Five within-subject comparative tasks
1. Save a real-sounding but non-sensitive supplier recommendation and retrieve tomorrow. 2. Retrieve an exact quoted phrase after a misleading similar item is introduced. 3. Find a note after a one-character typo. 4. Find the correct item among two conflicting records. 5. Recover gracefully when requested information was never captured. Counterbalance app order and build comparable starting conditions; do not give Doddy privileged preloaded memory unavailable to comparator.

**Record** task outcome adjudicated correct/wrong/miss, elapsed time from user intent to verified source, taps/utterances, user effort rating, permission friction, confidence calibration, preference reason, and whether character made task better or slower. Report results by app, task, and user.

## Naturalistic 28-day protocol
Day 0: baseline, transparent privacy explanation, sample non-sensitive save and taught recall. Days 1–14: no reminders to open Doddy; log content-free events with separate opt-in; one very short sampled substitution question after at most ~20% of organic successful sessions. Day 14: check-in questions without coaching. Days 15–28: natural behaviour continues; end interview including delete/export exercise. Keep a participant regardless of inactivity. Consent to research is distinct from OS permissions and analytics consent.

## Proposed decision gates: n=24 example

**Continue to deeper beta only when all safety gates and two of three behavioural gates pass:**
- Safety: no acknowledged saved-item loss; no reproduced false action-success; no unresolved severe privacy issue; every confidently wrong personal result investigated and corrected before expansion.
- Behavioural A: >=10/24 (42%) people independently initiate a real recall by day 14, with adjudicated outcomes reported.
- Behavioural B: >=8/24 (33%) people achieve at least **two** organic correct retrievals by day 28 (rather than forced daily opens).
- Behavioural C: >=8/24 report a concrete session where Doddy replaced a tool they normally used, supported by event context, not just “I like Doddy.”

**Hold / repair:** meaningful retrieval attempts exist but accuracy or effort falls short. **Pivot test:** users save frequently but rarely retrieve, while a different spontaneous use appears; validate a different single job separately. **Stop/defer:** users show neither independent recall nor displacement after one focused revision, or critical integrity issues persist. Thresholds are deliberately provisional and should be preregistered before recruitment.

## Specific misleading signals to exclude
Video views, fan enthusiasm, first-day usage, number of chats, synthetic retrieval benchmarks, generic survey enthusiasm, model-demo applause and being on a waitlist do **not** count as organic repeat utility or real payment.

## Rival hypothesis tests
- **Character vs plain utility:** same features, different personality treatment; recruit both fans and cold audience.
- **Text versus voice:** physical-device task tests in home, public, commuting (safe simulation) and low-noise settings; measure permissions and correction cost.
- **Recall vs follow-through:** compare 14-day voluntary recurrence of saved-item lookup against explicitly requested reminder creation; never treat action completion as verified without native confirmation.
- **Doddy vs Siri AI:** include eligible iOS 27 devices and supported Siri AI languages where possible; separately stratify devices without feature availability [S04].

## Decision evidence pack
Deliver CSV with participant IDs pseudonymised, cohort source, dates, attempts, adjudication, alternatives, errors, attrition and missingness; usability screen-recordings only with separate consent and scrubbed sample data. Publish a one-page result per gate with denominators and practical example, plus at least two disconfirming cases.


# H — Commercial Feasibility & Unit Economics
**Warning:** Revenue and conversion figures below are deliberate, transparent **scenarios**, not predicted signups, customer demand, real provider bills, or a finished price proposal.

## Commercial hypothesis
A user who relies on memory retrieval may later pay for convenience such as cross-device sync, advanced retrieval, larger history or optional voice access. P0 capture, correction, retrieval, export and deletion should remain available during validation; do not charge to recover the user's own saved data.

## Inputs and assumptions
- Hypothetical consumer price **$8/month excluding applicable taxes**, no validated willingness to pay.
- Assumed store reduction **15%** yielding **$6.80 net receipts per payer**; 15% is only applicable under relevant terms and eligibility, with jurisdiction-specific differences [S20].
- Assumed **35% of registrations are monthly active**, **6% of monthly active are paying**. These are invented scenario knobs, not conversion benchmarks.
- Assumed nonvoice per payer monthly variable cost **$0.55** (infra/support/other inference combined); free active user variable cost **$0.06**. Not measured.
- **GPT-Live-1 $0.05 per minute**, billed per second, *front-end voice only*; backend model and tools are additional [S14]. Do not assume this is Doddy's eventual provider.
- Active base represented by registrations × 0.35; expected payers are fractional expected values for scenario math, not fractional real accounts.

## Monthly contribution under the assumptions
| Registrations | MAU assumption | Expected payers | Text-first monthly contribution | Regular voice (40 min) contribution | Heavy voice (216 min) contribution |
|---:|---:|---:|---:|---:|---:|
| 100 | 35 | 2.1 | $11 | $7 | $-12 |
| 1,000 | 350 | 21.0 | $112 | $70 | $-115 |
| 10,000 | 3,500 | 210.0 | $1,115 | $695 | $-1,153 |
| 100,000 | 35,000 | 2,100.0 | $11,151 | $6,951 | $-11,529 |


*Monthly contribution = expected payer net receipts − payer variable costs − free-MAU variable costs. It excludes VAT/sales tax, acquisition cost, developer salaries, legal expense, fixed platform spend and churn. The scenarios above can become very negative with heavy voice consumption.*

## Per-paying-user economics
| Voice use | Voice-only cost | Total estimated variable cost (incl $0.55) | Net receipts | Monthly contribution | Margin before fixed/CAC |
|---|---:|---:|---:|---:|---:|
| Text-first/no live voice | $0.00 | $0.55 | $6.80 | $6.25 | 91.9% |
| 7 minutes | $0.35 | $0.90 | $6.80 | $5.90 | 86.8% |
| 40 minutes | $2.00 | $2.55 | $6.80 | $4.25 | 62.5% |
| 216 minutes | $10.80 | $11.35 | $6.80 | -$4.55 | negative |

**At the sample rates:** approximately **29.8 live voice minutes** are affordable per payer at a 70% contribution-margin target before counting free users or fixed spend. Break-even at 125 minutes excludes free-user subsidies and omitted charges. Actual quota must be based on observed distribution and the complete billing stack.

## Commercial decision
Do **not** launch a general subscription on day one. Test revealed preference in the successfully retained cohort: real paid-offer clicks, then a transparent paid pilot if repeat value and costs support it. Suggested candidate $5 / $8 / $10 / $15 monthly anchors are *experiments* only; test pricing with tax-correct local presentation, store policies and cancellation rights. Early launch could reasonably be free and text-first while usefulness is assessed.

## Risks
Retention cost curve, iOS platform defaults, app-store acquisition expense, model price changes, support burden, users expecting 'unlimited', storage/data export liabilities and user reluctance to pay for a Notes alternative. Research [S03] reports weaker payer retention among AI subscription apps overall; do not assume a character removes the problem.

## Next measured inputs required
Organic saved items/user, eligible recall frequency, median provider-free core cost, storage growth, 95th percentile voice minutes, subscription paid conversion among users who obtained two actual outcomes, net receipts after actual fees/tax, CAC/organic share, churn by cohort. Calculate contribution using real invoices after pilot.


# I — Implementation Roadmap
**Not calendar commitments.** Workstreams should be sequenced by value and real engineering verification, not aspirational release dates. Individual effort depends on developer availability, code quality and test devices.

## Milestone sequence
| Phase | Deliverable | Gate |
|---|---|---|
| R0 — Verify code and constraints | Test matrix with commit SHA, known defects, device traces | No blocking crash; implementation claims reconciled |
| R1 — Reliable local memory | P0 core flow that survives restart, storage errors | 100% acknowledged writes survive relevant fault tests |
| R2 — Consent and instrumentation | Privacy QA, metrics definitions and data export | No note/transcript content in events; permissions optional |
| R3 — Usability challenge | Counterbalanced task performance report | No unexplained personal misstatements; target time/effort advantage |
| R4 — Organic utility pilot | Recall/substitution cohort results and error audit | Pass preregistered behavioural and safety gates |
| R5 — Targeted expansion test | Separate device QA, cost and usefulness analysis | Demonstrated incremental user outcome without core regressions |
| R6 — Commercial decision | Price evidence + cohort contribution economics | Proceed to scale only if usage and economics justify it |


## Priority backlog and dependencies

| Ticket | Priority | Action | Dependency | Completion evidence |
|---|---|---|---|---|
| D-01 | P0 | Reconcile README, feature matrix, actual running app | none | Signed test matrix; exact SHA |
| D-02 | P0 | Remove mandatory simulated demo sign-in for first save | D-01 | Fresh install save works |
| D-03 | P0 | Design one capture/find native journey | D-01 | Usability pilot with real text |
| D-04 | P0 | Replace UserDefaults array with protected transactional store | D-01 | atomic write/migration/failure tests |
| D-05 | P0 | Bind `LocalRecallService` to native source-aware search | D-03,D-04 | local candidate IDs and provenance |
| D-06 | P0 | Add original/edited, correction, deletion, export | D-04 | restart/edit/delete/export fixtures |
| D-07 | P0 | Remove/segregate seeded demo examples | D-04 | no samples treated as personal |
| D-08 | P0 | Add explicit incomplete-query and no-match paths | D-05 | query fixture pass |
| D-09 | P0 | Add accessibility and offline coverage | D-03–D-08 | actual iPhone device matrix |
| D-10 | P0 | Build consent, privacy and content-free analytics | D-04 | security/privacy review and schema validation |
| D-11 | P0 | Prepare 28-day research build | D-01–D-10 | tested TestFlight, rollback plan |
| D-12 | P1 | Test foreground real dictation | D-01,D-03 | supported languages, time/correction/cost measured |
| D-13 | P1 | Implement typed Apple Reminders proposal/write | D-01,D-04 | EventKit confirmed IDs, permission failures tested |
| D-14 | P1 | Control Center on supported iOS | D-03 | extension, invocation test |
| D-15 | P1 | Semantic recall with citations | real query dataset | beats baseline; no fabricated sources |
| D-16 | P2 | Cloud models/live voice/long-term companion chat | clear user demand, risk/cost controls | production architecture review |
| D-17 | P2 | Cross-device sync and accounts | demonstrated retained demand | identity, backup, deletion/security audit |

## Estimation (relative planning only)
**Lower complexity:** replacing demo prompt copy, basic capture/search UI, telemetry definitions. **Medium:** atomic datastore migration, search-source UX, multilingual recall test bench, privacy notices. **Higher:** reliable live speech, EventKit idempotency, secure sync and multi-tool agent. These categories are not delivery-time promises; engineering estimate requires first running the app and examining the code under Xcode.

## Risk register

| Risk | Consequence | Mitigation and stop condition |
|---|---|---|
| Low natural retrieval frequency | No ongoing value | Compare with Notes in 28-day pilot; pivot job if little retrieval |
| Hallucinated recall | Trust breach | Source-only candidate results; zero tolerance for unsourced confident assertions |
| Storage migration regression | Lost records | Transactional copy-read-verify-swap; never delete old until confirmed |
| Siri AI rapidly improving | Differentiation shrinks | Re-run competitor task comparison each meaningful release [S04] |
| Voice acquisition and use cost | Poor contribution | Treat as experimental add-on, quota scenario, no 'unlimited' |
| Character slows critical tasks | Higher abandonment | Focused state for useful tasks, reduced motion and no forced greetings |
| Privacy breach/analytics content | Trust, GDPR exposure | Local-first, content-free event schema, explicit consent and review [S17] |
| Pilot overfit to fans | False product-market evidence | Recruit fan and cold segment separately; preference test blinded |

## Do not cross the commercial release gate without
1. Reproducible secure persistence and correctly attributable retrieval; 2. consent and legal basis assessed; 3. observed external-user organic substitution and repeat; 4. documented voice/tool real-world behaviour, if included; 5. contribution economics from actual bills; 6. Apple platform policy and App Review assessment.


# Evidence and citations

Evidence as of **8 October 2026**. References support individual claims; they do not establish Doddy-specific demand. Private repository citations require access.

- **[S01]** [Pew Research Center (2026), Americans and AI](https://www.pewresearch.org/internet/2026/06/17/americans-and-ai-2026-chatbots-smart-devices-and-views-on-impact/) — US adults survey; not a Doddy user cohort.
- **[S02]** [NBER (2025), How People Use ChatGPT](https://www.nber.org/papers/w34255) — Representative ChatGPT conversation classification; provider-associated authors.
- **[S03]** [RevenueCat (2026), State of Subscription Apps](https://www.revenuecat.com/state-of-subscription-apps) — Subscription app dataset; may have selection bias and is not Doddy retention.
- **[S04]** [Apple (2026), Siri AI release](https://www.apple.com/newsroom/2026/09/siri-ai-a-profoundly-more-capable-and-personal-assistant-is-here/) — Official announced and beta capabilities; availability varies by language/device.
- **[S05]** [Apple Developer, EventKit permissions](https://developer.apple.com/documentation/EventKit/accessing-the-event-store) — Official API permissions and write constraints.
- **[S06]** [Apple Support, run Shortcuts with Back Tap](https://support.apple.com/en-gb/guide/shortcuts/apd897693606/ios) — User must configure assignment in Settings.
- **[S07]** [Apple Developer, App Intents](https://developer.apple.com/documentation/AppIntents) — Exposed actions and OS integration; not arbitrary control.
- **[S08]** [Apple Developer, controls and Live Activities](https://developer.apple.com/documentation/appintents/widgets-live-activities-and-controls) — Controls can be placed in Control Center/Lock Screen/Action Button.
- **[S09]** [Apple Developer, Japan side-button access](https://developer.apple.com/documentation/AppIntents/Launching-your-voice-based-conversational-app-from-the-side-button-of-iPhone) — Region restricted to Japan.
- **[S10]** [OpenAI, ChatGPT Memory](https://help.openai.com/en/articles/8590148-memory-in-chatgpt) — Competing personal-context functionality.
- **[S11]** [OpenAI, Scheduled tasks in ChatGPT](https://help.openai.com/en/articles/10291617-scheduled-tasks-in-chatgpt) — Competing tasks/notifications feature; access varies.
- **[S12]** [OpenAI, ChatGPT Voice](https://help.openai.com/en/articles/20001274-chatgpt-voice) — Competing real-time voice; plan/platform dependent.
- **[S13]** [Google, Gemini reminders and tasks](https://support.google.com/gemini/answer/15230285) — Competing integrated tasks.
- **[S14]** [OpenAI API, GPT-Live-1](https://developers.openai.com/api/docs/models/gpt-live-1) — Public $0.05/min voice session rate; backend separate.
- **[S15]** [Apple Developer, SpeechAnalyzer](https://developer.apple.com/documentation/speech/speechanalyzer) — Speech-to-text module, device/language checks required.
- **[S16]** [Apple Developer, speech authorization](https://developer.apple.com/documentation/speech/asking-permission-to-use-speech-recognition) — Privacy/permission distinctions between speech APIs.
- **[S17]** [European Commission, GDPR principles](https://commission.europa.eu/law/law-topic/data-protection/reform/rules-business-and-organisations/principles-gdpr/overview-principles/what-data-can-we-process-and-under-which-conditions_en) — Data minimisation, accuracy, purpose limitation and transparency.
- **[S18]** [ACM CHI 2025, OmniQuery](https://doi.org/10.1145/3706598.3713448) — Personal-memories retrieval feasibility; not proof of consumer adoption.
- **[S19]** [Common Sense Media 2025, companion study](https://www.commonsensemedia.org/research/talk-trust-and-trade-offs-how-and-why-teens-use-ai-companions) — Teen-specific safety evidence; product research restricts initial sample to adults.
- **[S20]** [Apple, App Store Small Business Program](https://www.apple.com/newsroom/2020/11/apple-announces-app-store-small-business-program/) — 15% qualifying commission, subject to eligibility and jurisdictional changes.
- **[S21]** [Apple Developer, App Intents runtime behavior](https://developer.apple.com/documentation/appintents/configuring-the-runtime-behavior-of-your-app-intents) — Foreground/background governed by system constraints.
- **[S22]** [Apple Developer, app shortcuts](https://developer.apple.com/documentation/appintents/app-shortcuts) — Supported invocation experience.
- **[S23]** [Repository README, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/README.md) — Connected repo inspected 8 October 2026.
- **[S24]** [Repository product spec, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/PRODUCT_SPEC.md) — Prior proposed memory direction, not adoption evidence.
- **[S25]** [Repository feature matrix, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/FEATURE_MATRIX.csv) — Implementation status as documented; not independently built on device.
- **[S26]** [Repository validation plan, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/VALIDATION.md) — Existing 5 Oct assumptions and test design.
- **[S27]** [Repository engineering, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/ENGINEERING.md) — Data/persistence and service contracts.
- **[S28]** [Repository business model, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/BUSINESS.md) — Previously modelled assumptions; unvalidated pricing.
