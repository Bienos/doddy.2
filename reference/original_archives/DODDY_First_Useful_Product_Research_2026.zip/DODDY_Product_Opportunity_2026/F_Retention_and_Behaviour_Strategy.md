# F — Retention, Activation and Responsible Engagement
**No observed Doddy cohorts exist in this report.** Targets below are proposed decision heuristics, not industry norms.

## Primary metric
**Weekly users with at least one independently verified, organic correct retrieval**, divided by all eligible enrolled users for the corresponding cohort. This captures the delayed outcome, not just note accumulation. Because recall is episodic, also report **28-day meaningful outcome retention** and time-to-next-natural-need. A daily streak is the wrong North Star.

**Metric tree:** eligible enrolled → first real save → later organic recall attempt → correct adjudicated recall → displaced alternative workflow → second organic correct recall → willingness to keep/use/pay. Guardrails: confirmed-wrong results, false save success, privacy complaints, time-to-value, error rate, disable/delete requests.

## Denominators and interpretations
- `Activation`: first real saved record persisted and verified / all qualified installations. Do **not** confuse with two-step memory utility.
- `Delayed utility conversion`: at least one independently initiated and adjudicated correct retrieval within 14 days / all qualified installations.
- `D1, D7, D30 return`: any organic session on exact local day among installed users, including zeros; report separately from task-success retention.
- `W1/W2 meaningful user`: >=1 organic correct recall in each interval / all originally eligible users; reports with n counts and missing classifications.
- `Recall precision`: correct targeted source among adjudicated responses / adjudicated source responses; uncertain and unjudged not silently counted correct.
- `Confirmed-wrong confident rate`: incorrect assertive matches / assertive matches independently adjudicated. One harmful high-confidence wrong claim is investigated.
- `Substitution`: sampled sessions where participant would otherwise use another tool and Doddy completed the same job / answered sampled sessions; disclose response bias.
- `Quick access value`: net task effort, cold/warm invocation time, successful completion; never infer from shortcut activation count alone.

## Ten testable retention hypotheses
| ID | Hypothesis | Test / directional target | Falsifier |
|---|---|---|---|
| H01 | Recent Notes/self-message users will try explicit capture | Observe 3+ captures during 14 days without reminders | <20% capture twice organically |
| H02 | Later retrieval is a meaningful job | ≥40% enrolled initiate ≥1 spontaneous recall by day 14 | <20% initiate any recall |
| H03 | Visible sources improve trust | Participants correctly identify record provenance ≥90% in tasks | Source display ignored or causes confusion |
| H04 | One entry point can replace self-message | ≥30% of respondent substitution samples name a displaced tool | <10% report substitution |
| H05 | Text beats microphone in shared spaces | Diary shows voice avoided in shared settings; A/B preference | Voice strongly preferred across contexts |
| H06 | Voice enhances capture while moving | 20%+ task-time reduction in observed hands-busy conditions | High error / permission drop-off |
| H07 | Character adds approachability without slowing use | No meaningful increase in completion time; preference split by fan/nonfan | Cute reactions frustrate time-pressed users |
| H08 | Saved originals outperform auto-inferred memories in trust | Fewer wrong-confident answers and higher source confidence than generative baseline | Recall misses too many paraphrases |
| H09 | Native reminders are a demanded next job | ≥25% retained users spontaneously ask for confirmed action | <10% ask after 28 days |
| H10 | Users will pay only after seeing retrieval value | Some users complete real paid test after seeing repeat value | Only survey stated preference; no paid conversion |


## Natural return triggers
An independent need for a saved recommendation, a product detail, a question to ask later, an earlier project decision, or a voluntarily initiated retrieval. Capture alone may become a daily pattern for some people but is not proof that the saved content is useful. Notifications should only reflect explicit user-requested tasks; no 'I miss you', personal guilt or spontaneous emotional checking-in.

## Character contribution experiment
Randomise on first-use demo into **utility-neutral confirmation** (“Saved”) versus **restrained character voice** (“Got it. Saved exactly like that.”), keeping storage/retrieval identical. Blind follow-up with unfamiliar users and existing character fans separately. Measure comfort, comprehension and speed; do not use total conversation minutes as a success proxy.

## Personalisation boundaries
Personal memory is user-selected content. Do not automatically transform every chat into durable facts. No inferential profiling, private relationship predictions or hidden cross-app indexing. Context references only when directly relevant and sourced. 'Mate' describes tone and access, not emotional dependence or reciprocity. Adult-only pilot; no engagement optimisation targeted at loneliness [S19].

## Research validity safeguards
Separate onboarding tutorials, staff prompts, notification-triggered traffic, content fans and organic return. Do not remove inactive participants from denominators. Report median and individual range (not only aggregate average), device/OS capability and whether alternatives were available. Do not benchmark exploratory pilot percentages as population retention.
