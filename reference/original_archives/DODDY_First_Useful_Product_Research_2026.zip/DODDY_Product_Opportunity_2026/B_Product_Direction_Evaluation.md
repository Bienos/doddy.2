# B — Ten Product Directions and Decision Matrix
**All numerical ratings are editorial estimates (1–5), not measured user preference or validated market forecasts.**

## Decision rule
Choose a **single repeatable job** with testable substitution and feasible first delivery. Score 1 (weak) to 5 (strong); weighted average uses explicit weights and no hidden adjustment. See `data/10_Direction_Weighted_Scores.csv` for every raw score.

| Criterion | Weight | Criterion | Weight |
|---|---:|---|---:|
| Problem severity | 18% | Repeat potential | 15% |
| Differentiation | 15% | Perceived value | 12% |
| MVP feasibility | 10% | Reliability | 10% |
| Low friction | 8% | Monetisation | 5% |
| Character fit | 4% | Sustainability | 3% |

| Rank | Direction | Weighted score / 5 | Weakest assumption |
|---:|---|---:|---|
| 1 | A · Explicit memory | 3.99 | Users may save but never retrieve |
| 2 | C · Follow-through | 3.76 | Reliability and permission complexity |
| 3 | I · General agent | 3.55 | Large scope, frequent tool failures |
| 4 | H · Learning | 3.48 | Mature tutors already available |
| 5 | G · Day planner | 3.47 | Calendar access and incumbent integration |
| 6 | B · Voice-first access | 3.33 | Siri/ChatGPT already solve it |
| 7 | F · Problem solver | 3.32 | No distinctive job or retrieval moat |
| 8 | E · Translation | 3.19 | Situational; strong native alternatives |
| 9 | D · Context agent | 3.16 | Requires broad sensitive data |
| 10 | J · Open-ended mate | 3.13 | Entertainment mistaken for utility |


## Ten competing hypotheses, genuinely different MVPs

| Direction | Narrow audience and primary job | Smallest demonstration | Central failure risk |
|---|---|---|---|
| A: Explicit memory | People saving scattered details | Save one statement, retrieve with source later | Never return for recall; Notes is enough |
| B: Voice-first access | People who often cannot type | Invoke, ask, hear answer quickly | System voice assistant access is faster |
| C: Follow-through | People who forget action commitments | Translate explicit intention into verified reminder | Too similar to Siri; action failure destroys trust |
| D: Personal-context agent | Heavy AI users seeking continuity | One connected data source, contextual answer | Privacy/trust overhead; Siri/ChatGPT incumbent |
| E: Translation | Bilingual travellers / families | Low-latency two-way turn exchange | Occasional travel use, language accuracy stakes |
| F: Problem solver | People facing small practical problems | Quick guided answer to known high-frequency task | Generic ChatGPT or search wins |
| G: Day planner | Calendar-heavy users | View and reorganise one day's commitments | Calendar privacy + mature native alternatives |
| H: Learning | Self-directed learners | Repeat one explanation with understanding check | Numerous specialist tutors, low differentiation |
| I: Autonomous agent | Users delegating multi-app tasks | Verified multi-step action with confirmation | API scope, unreliability, operational cost |
| J: Open-ended mate | Entertainment-first character fans | Pleasant chat with gentle assistance | Novelty, attachment risk, weak willingness to pay |

## Decision and bounded combination
**Primary job:** capture an explicitly saved useful thought and find its original information later. **Supporting 1:** low-friction text entry + optional existing Shortcut. **Supporting 2:** provenance and user correction/deletion controls. **Secondary experiment:** verified Apple Reminder creation *after* recall succeeds and users request it repeatedly. Real conversational voice remains a parallel feasibility experiment, not a release blocker for the memory-value test.

The first outcome includes **two separate moments**: capture successfully persisted now and independent later retrieval. No 'activation' based only on talking with Doddy.

## Challenges to the winner
A high composite score is not market proof. Memory may lose for three reasons: (1) retrieval opportunities may be too infrequent; (2) Notes/Siri search may already be good enough; (3) people may not trust putting personal details into a new product. The app must measure repeated source-backed recall and substitution directly. A feature called 'memory' is not differentiated if ChatGPT, Apple and Google can remember too [S04,S10,S13].

## Sensitivity / decision reversal tests
- If the chosen cohort reports **almost no retrieval**, A's repetition and value assumptions decline; C or a narrower segment may win.
- If protected persistence proves difficult, A's feasibility score falls and confidence must drop; no 'saved' confirmation without durable write.
- If Siri AI on compatible phones matches Doddy's full save/retrieve flow at equal effort, A's differentiation score should approach 1–2 and the product should pivot/stop.
- If user-initiated recurring reminders vastly exceed retrieval attempts, test C in its own controlled experiment rather than silently adding ten integrations.
- Different weight choices can reorder A/C/I; this matrix is a transparent prioritisation exercise, **not objective proof**.

## Hard exclusions for v1
No open-ended autonomous agent; no broad connected-app ingestion; no calendar/email/contacts scraping; no passive memory from every conversation; no always-on microphone; no full-screen ambient overlay; no character-driven push notifications; no complex social feeds or gamification; no paid memory extraction lock-in.
