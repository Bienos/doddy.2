# A — Consumer AI Opportunity Research
**Version 1.0 · 8 October 2026 · Decision research, not user validation**

## Question and comparison
Can Doddy displace an existing repeated consumer behavior with a more useful interaction? We consider adult iPhone users with a **demonstrated habit of capturing small useful thoughts** in Notes, Reminders, screenshots or messages to themselves. This is an initial recruitment hypothesis, not an asserted customer segment.

## Evidence ledger: what is established

| Observation | Implication for Doddy | Evidence status |
|---|---|---|
| 49% of US adults reported ever using AI chatbots; roughly one-quarter reported daily use (Pew Feb 2026). | Familiarity exists, but usage adoption does not demonstrate room for another assistant. | VERIFIED for surveyed US adults [S01] |
| Practical guidance, seeking information and writing were the largest ChatGPT conversation categories in research through July 2025. | General questions and writing are crowded; conversational usefulness is real. | VERIFIED for studied ChatGPT traffic, not all products [S02] |
| RevenueCat's 2026 subscription-app cohort shows AI apps with stronger payer monetisation yet weaker 12-month retention than non-AI. | Do not select a hook based on demos or short-term conversion alone. | VERIFIED for RevenueCat dataset, not Doddy [S03] |
| Apple announced Siri AI with personal context, systemwide actions, onscreen understanding and conversation in September 2026. English rollout is beta. | 'Siri but warmer' is fragile differentiation; test on compatible devices and markets. | VERIFIED announced capabilities, rollout varies [S04] |
| ChatGPT provides personal context, scheduled tasks and voice; Gemini supports connected reminders/tasks. | Memory, reminders and voice are features, not individually defensible moats. | VERIFIED documented feature families [S10-S13] |
| Research at CHI 2025 demonstrates personal recall over captured information can be technically difficult, with context and provenance important. | Traceable original capture and constrained retrieval should precede generated personal answers. | Research-supported engineering consideration, not market demand [S18] |

## Competitive substitution landscape

| Existing choice | Strength | Likely Doddy disadvantage | Potential experiment |
|---|---|---|---|
| Apple Notes | Free, familiar, sync/search, native | User already has it; Doddy adds friction if recall isn't materially better | Capture a thought then find it later, time and error comparison |
| Apple Reminders | Reliable native triggers, Siri/OS integrated | Doddy cannot beat it at basic reminder reliability without integration | Test intent capture / follow-through only after recall succeeds |
| Siri AI | Deep OS context and controls on supported devices | Third-party OS integration is weaker; access may be slower | Narrow source-auditable user-selected memory; compare on iOS 27 |
| ChatGPT | Strong general chat, voice, memory, tasks | User may already pay; duplicating it has low value | Blind preference test on explicit saved-item retrieval |
| Gemini | Tasks, search, Google context, voice on supported products | Large connected ecosystem | Do not replicate generic tasks |
| Perplexity / search | Broad information retrieval | Doddy cannot compete on general search breadth initially | Focus on user-saved private context rather than world facts |
| Replika / Character.AI | Engaging personality or roleplay | Companionship does not establish practical task utility | Character-only versus utility-only condition |
| Self-messages / screenshots | Capture with essentially zero learning cost | Doddy needs improved later retrieval without privacy creep | Measure genuine workflow substitution |
| Personal task apps | Mature notifications and status tracking | Replacing them requires consistency and integration | Only pursue after repeated user-initiated demand |

**Critical competitive update:** In September 2026, Siri AI entered English beta with more capable personal context and app actions [S04]. Future Doddy differentiation must remain compelling on compatible devices; temporary regional or language gaps are not a durable moat.

## Opportunity atlas: 100 situations
The accompanying `data/100_Opportunity_Atlas.csv` contains **100 individually defined hypothetical jobs**, each labelled by trigger, existing substitute, friction, frequency, context required, input route, intended result, risk and technical feasibility. These are *research hypotheses*, not interviews or observed demand. Coverage is ten domains with ten situations each: capture/recall, personal administration, relationships, shopping, travel, projects, study, planning, home and communication.

**High-priority jobs to test first** are saving a thought without choosing a folder; finding the exact recommendation someone mentioned; recovering the latest version of an explicitly saved decision; finding a warranty/return detail; and retrieving an idea captured while occupied. Low-priority jobs include broad research, arbitrary autonomous actions, background monitoring, and tasks already solved well by native reminders.

## Ranked behavioural job clusters

| Cluster | Repeat hypothesis | Friction | Dominant alternative | MVP suitability |
|---|---|---|---|---|
| Capture small facts / later retrieve | Often weekly, sometimes daily; must measure | Information scattered across applications and contexts | Notes, search, self-messaging | Highest: text-first, private, bounded |
| Complete follow-through after an intention | Frequently useful but failure stakes higher | Intent is expressed but action never completed | Reminders, calendars, habit tools | Medium: EventKit test after stable core |
| Voice question while hands occupied | Depends on setting and social comfort | Unlock, find app, type | Siri AI, ChatGPT Voice | Medium: access/latency differentiator unproven |
| Plan tasks across calendars/apps | Potentially daily for some | Fragmented tasks | Siri, calendars, work tools | Low: permissions/integrations heavy |
| Real-time translation | Situational and high-value for travellers | Turn-taking and language friction | System translation, Gemini/ChatGPT | Alternative experiment, not primary |
| Entertainment chat | Could be frequent without solving jobs | Novelty decay, substitution uncertainty | Character.AI, social media | Separate acquisition strategy; no assumed utility |

## Research gaps and source limitations
No participant interviews, field observation, retention measurements or head-to-head comparison has been performed for this report. US adoption data cannot infer Polish or EU preferences; RevenueCat subscription cohorts differ from a free-first character app; repository tests do not establish human recall usability; private notes contain sensitive material even if stored locally. Self-selection into a Doddy fan audience could inflate affinity and mask weak product need.

**Next step:** recruit people based on a *recent concrete instance* of losing, searching for or remembering a useful detail—not enthusiasm for Doddy or AI.

See [SOURCES.md](SOURCES.md) for clickable evidence references.
