# Evidence and citations

Evidence as of **8 October 2026**. References support individual claims; they do not establish Doddy-specific demand. Private repository citations require access.

- **[S01]** [Pew Research Center (2026), Americans and AI](https://www.pewresearch.org/internet/2026/06/17/americans-and-ai-2026-chatbots-smart-devices-and-views-on-impact/) — US adults survey; not a Doddy user cohort.
- **[S02]** [NBER (2025), How People Use ChatGPT](https://www.nber.org/papers/w34255) — Representative ChatGPT conversation classification; provider-associated authors.
- **[S03]** [RevenueCat (2026), State of Subscription Apps](https://www.revenuecat.com/state-of-subscription-apps) — Subscription app dataset; may have selection bias and is not Doddy retention.
- **[S04]** [Apple (2026), Siri AI release](https://www.apple.com/newsroom/2026/09/siri-ai-a-profoundly-more-capable-and-personal-assistant-is-here/) — Official announced and beta capabilities; availability varies by language/device.
- **[S05]** [Apple Developer, EventKit permissions](https://developer.apple.com/documentation/EventKit/accessing-the-event-store) — Official API permissions and write constraints.
- **[S06]** [Apple Support, run Shortcuts with Back Tap](https://support.apple.com/en-gb/guide/shortcuts/apd897693606/ios) — User must configure assignment in Settings.
- **[S07]** [Apple Developer, App Intents](https://developer.apple.com/documentation/AppIntents) — Exposed actions and OS integration; not arbitrary control.
- **[S08]** [Apple Developer, controls and Live Activities](https://developer.apple.com/documentation/appintents/widgets-live-activities-and-controls) — Controls can be placed in Control Center/Lock Screen/Action Button.
- **[S09]** [Apple Developer, Japan side-button access](https://developer.apple.com/documentation/AppIntents/Launching-your-voice-based-conversational-app-from-the-side-button-of-iPhone) — Region restricted to Japan.
- **[S10]** [OpenAI, ChatGPT Memory](https://help.openai.com/en/articles/8590148-memory-in-chatgpt) — Competing personal-context functionality.
- **[S11]** [OpenAI, Scheduled tasks in ChatGPT](https://help.openai.com/en/articles/10291617-scheduled-tasks-in-chatgpt) — Competing tasks/notifications feature; access varies.
- **[S12]** [OpenAI, ChatGPT Voice](https://help.openai.com/en/articles/20001274-chatgpt-voice) — Competing real-time voice; plan/platform dependent.
- **[S13]** [Google, Gemini reminders and tasks](https://support.google.com/gemini/answer/15230285) — Competing integrated tasks.
- **[S14]** [OpenAI API, GPT-Live-1](https://developers.openai.com/api/docs/models/gpt-live-1) — Public $0.05/min voice session rate; backend separate.
- **[S15]** [Apple Developer, SpeechAnalyzer](https://developer.apple.com/documentation/speech/speechanalyzer) — Speech-to-text module, device/language checks required.
- **[S16]** [Apple Developer, speech authorization](https://developer.apple.com/documentation/speech/asking-permission-to-use-speech-recognition) — Privacy/permission distinctions between speech APIs.
- **[S17]** [European Commission, GDPR principles](https://commission.europa.eu/law/law-topic/data-protection/reform/rules-business-and-organisations/principles-gdpr/overview-principles/what-data-can-we-process-and-under-which-conditions_en) — Data minimisation, accuracy, purpose limitation and transparency.
- **[S18]** [ACM CHI 2025, OmniQuery](https://doi.org/10.1145/3706598.3713448) — Personal-memories retrieval feasibility; not proof of consumer adoption.
- **[S19]** [Common Sense Media 2025, companion study](https://www.commonsensemedia.org/research/talk-trust-and-trade-offs-how-and-why-teens-use-ai-companions) — Teen-specific safety evidence; product research restricts initial sample to adults.
- **[S20]** [Apple, App Store Small Business Program](https://www.apple.com/newsroom/2020/11/apple-announces-app-store-small-business-program/) — 15% qualifying commission, subject to eligibility and jurisdictional changes.
- **[S21]** [Apple Developer, App Intents runtime behavior](https://developer.apple.com/documentation/appintents/configuring-the-runtime-behavior-of-your-app-intents) — Foreground/background governed by system constraints.
- **[S22]** [Apple Developer, app shortcuts](https://developer.apple.com/documentation/appintents/app-shortcuts) — Supported invocation experience.
- **[S23]** [Repository README, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/README.md) — Connected repo inspected 8 October 2026.
- **[S24]** [Repository product spec, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/PRODUCT_SPEC.md) — Prior proposed memory direction, not adoption evidence.
- **[S25]** [Repository feature matrix, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/FEATURE_MATRIX.csv) — Implementation status as documented; not independently built on device.
- **[S26]** [Repository validation plan, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/VALIDATION.md) — Existing 5 Oct assumptions and test design.
- **[S27]** [Repository engineering, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/ENGINEERING.md) — Data/persistence and service contracts.
- **[S28]** [Repository business model, private GitHub](https://github.com/Bienos/AI-AGENT-DODDY/blob/main/docs/product/BUSINESS.md) — Previously modelled assumptions; unvalidated pricing.
