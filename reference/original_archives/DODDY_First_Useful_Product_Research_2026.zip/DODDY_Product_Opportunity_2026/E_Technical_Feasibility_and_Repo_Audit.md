# E — Technical Feasibility and Current Repository Audit
**Repository inspected with connected GitHub access on 8 October 2026:** [`Bienos/AI-AGENT-DODDY`](https://github.com/Bienos/AI-AGENT-DODDY) (`main`). This is a **document and code-path inventory**, not a fresh local Xcode build or penetration test. README/product spec/feature matrix/engineering/backlog read; device behaviour unverified.

## What exists versus what does not

| Component | Current implementation status, per repository | Next required proof |
|---|---|---|
| SwiftUI iPhone prototype | Existing `Companion.xcodeproj`, iOS 17+ target | Build, simulator and physical device test |
| Conversational controller | Scripted questions/answers and mocked listening | Connect provider with cancellation/stale result tests |
| Shortcuts invocation | `TalkToCompanionIntent`, invocation router in source | Test actual Shortcut, cold start, signed-out experience |
| Back Tap | Documented manual setup | User config + physical device tests; app cannot assign automatically |
| Local memory | `MemoryItem`, `AppState`, original/edit text, source metadata | Native memory UI wiring and protected storage upgrade |
| Local recall | `LocalRecallService` lexical/fuzzy candidate retrieval | Real participant retrieval accuracy, Polish inflection and natural paraphrases |
| Memory tests | README states 33 tests + synthetic 50 records/100 queries | Independently execute current suite and inspect failures |
| Persistence | UserDefaults JSON | Replace with atomic protected throwing store |
| Voice/audio | **Mock only**; no real mic or playback | Foreground permission, audio, interruptions and transcripts |
| AI | **Mock only**, no live provider or key broker | Product need and secure inference architecture first |
| Apple Reminders | **Not implemented** | Typed proposal, EventKit permission, verified write |
| Account | Demo local provider choice only | Remove demo wall for beta or implement real auth after need |
| Control Center / Island | Browser showcase/planned; no native service | Extension/ActivityKit feasibility separately |
| Analytics | Schema/specification only | Content-free opt-in implementation and consent audit |

Repo source references: [S23–S28]. The referenced `docs/product/VERIFICATION.md` was not retrievable at the exact path during this review, so the reported test execution and native QA could not be independently verified.

## Recommended minimal architecture
`SwiftUI capture/search UI → validated domain operations → MemoryStore (transactional, file protected) → LocalRecallService → source-linked result`. Keep local domain layer free from cloud model dependencies for the first utility validation. Replace UserDefaults with one well-tested option (SQLite/GRDB, SwiftData or atomic protected local file); choose based on required query/index size and migration guarantees, not architectural fashion. SQLite FTS5 can be introduced when lexical performance justifies it.

**P0 requires no cloud model.** Doddy's persona can appear in product copy, light reaction and confirmations without hallucinated chat. The live companion architecture should remain modular behind `AIService` and `SpeechService`, then be introduced after baseline utility evidence.

## Voice technology and honest constraints
- `SpeechAnalyzer` / `SpeechTranscriber` offers a speech-to-text route with supported runtime assets; check language availability, OS versions and physical-device behaviour. Older `SFSpeechRecognizer` can involve server processing and requires distinct disclosure [S15–S16].
- Apple permits App Intents / Shortcuts; users configure Back Tap in Accessibility settings; applicable Action Buttons are manually assigned [S06–S08].
- Controls can appear in supported Control Center/Lock Screen contexts, but an interactive Control does not grant permission to record arbitrary background audio or inspect all app content [S08,S21].
- Apple's third-party conversational **side-button replacement** feature is documented for iPhone **in Japan** with entitlement and region requirements. Do not sell it as a Poland/EU feature [S09].
- Dynamic Island / Live Activities should represent a genuinely ongoing user-permitted activity, not an always-running animated pet or fake assistant progress indicator.
- Apps cannot programmatically assign their own Back Tap setting by default [S06].

## EventKit follow-through contract (P1 only)
`intent → propose {operationId,title,dueDate,tz} → clarify dates → request explicit permission → persist pending operation → EventKit save → reconcile external ID → show success`. EventKit asks for full Reminders access, while Calendar permissions include write-only event access options; do not conflate them [S05]. If denied, offer an unscheduled saved note without claiming a reminder exists. Timezone/daylight saving, interrupted writes, duplicate retries and deletion/undo require device tests.

## Failure model
| Failure | UX behaviour | Engineering check |
|---|---|---|
| disk full/protection lock | Do not claim save; preserve draft | fault-injected store write |
| corrupted previous data | Preserve raw unreadable bytes; offer recovery | migration rollback test |
| no recall match | Explicit miss, show source search suggestions | curated miss corpus |
| conflicting notes | Show originals/dates, ask | conflict fixture |
| unsupported time filter | State limitation; no dropped constraint | date-expression fixture |
| voice permission denied | Text is fully functional | permission denial device test |
| background interruption | Stop audio and prevent stale completion | lifecycle harness + device |
| external reminder ambiguous | Confirm before writing | timezone/relative time cases |

## Privacy/security boundaries
For P0, no contact/email/photos access. Records are personal data and may be sensitive. Secure local file permissions, protected storage, minimise analytics, ensure deletion/export, document backups and provider boundaries if later introduced. Local-first is **not** GDPR exemption [S17]. Threat model: device theft, backup leakage, data migration errors, malicious shared strings (if Share Sheet added), prompt injection through retrieved text (if LLM enabled later), and accidental logs.

## Engineering gate sequence
1. Run repository's existing Swift tests and Xcode build; record exact SHA/device/OS. 2. Replace demo storage transactionally. 3. Connect minimal native UI. 4. Verify capture/recall against labelled real queries. 5. Add opt-in analytics. 6. Ship controlled text beta. 7. Only then implement and test voice/EventKit modules separately.
