# D — MVP Product Requirements Document (PRD)
**Status:** recommended for validation; not an approved product baseline. **Target platform:** iPhone, initial compatibility iOS 17+ subject to Xcode/device testing. **North-star job:** explicit save → later correct recall.

## Scope locked for first external text beta

| ID | Priority | Feature | Business rule | Acceptance criterion |
|---|---|---|---|---|
| P0-01 | P0 | Zero-account first use | Start without external provider login | New install saves own note with no demo login selection |
| P0-02 | P0 | Explicit text capture | Only `Save` or clear intent writes | No passive extraction; content copied exactly |
| P0-03 | P0 | Protected reliable storage | Atomic, throwing local persistence | Cold-restart readback matches committed item; errors visible |
| P0-04 | P0 | Capture provenance | Date (if known), input source, original text, current text | Legacy unknown stays unknown; no fabricated timestamps |
| P0-05 | P0 | Candidate recall | Exact/normalized terms, bounded fuzzy; records only | Correct candidate IDs; explicit miss/ambiguity and unsupported constraints |
| P0-06 | P0 | Source display | Quote original note; show edit flag | Response source links back to stored record |
| P0-07 | P0 | Correction / delete / export | User controls saved content | Edits persist; deletion confirmed; export usable offline |
| P0-08 | P0 | Fail-safe UX | No false action success | Disk full, locked store and corrupt migration not reported as saved |
| P0-09 | P0 | Text input and accessibility | Voice not necessary | Full flow via keyboard, VoiceOver, Dynamic Type and reduced motion |
| P0-10 | P0 | Privacy and safety baseline | Adult participants; no hidden analysis | Clear explanation; data-minimal content-free telemetry opt-in |
| P1-01 | P1 | Foreground voice dictation | Permissioned real capture on device | Real audio measured; transcript correction and text fallback |
| P1-02 | P1 | Verified Apple Reminder | Explicit request, resolved date, EventKit success | External ID persisted; retries idempotent; denied permission honest |
| P1-03 | P1 | Control Center / advanced quick access | Supported OS and extension | Device tested; no default Back Tap configuration claim |
| P1-04 | P1 | Semantic recall | Source-grounded paraphrase over candidates | Human-labeled multilingual evaluation beats lexical baseline safely |
| P2-01 | P2 | Live speech conversation | Full audio loop and voice UX | Meaningful use warrants measured costs and latency |
| P2-02 | P2 | Sync and account identity | Opt-in multi-device | Threat model, backup, export/delete, isolation checked |
| P2-03 | P2 | Calendar/email/other actions | Only after observed demand | Individual permission/reliability gate per action |
| EX-01 | Excluded | Always-on listener, autonomous app operator, generic screen overlay, character-driven daily notifications | Not a credible MVP | Remain absent |

## Core functional user stories
**US-01:** As a user with a useful thought, I can save an explicit record so I don't have to choose a folder. **Given** nonempty text <= 5,000 characters **when** I tap Save **then** the app durably commits it and shows exactly what was accepted; **if** commit fails, it retains a recoverable draft and never says 'Saved'.

**US-02:** As a returning user, I can retrieve a record using distinctive words. **Given** saved notes **when** I search **then** the app returns relevant stored items and timestamps, not inferred facts; unsupported temporal filters are explicitly called out.

**US-03:** As a user with two similar items, I can choose among them. **Given** ambiguous matches **when** I query **then** at least two options and provenance are presented; no single unsupported answer is asserted.

**US-04:** As a user correcting a note, I can edit or delete it without losing control. **Given** saved record **when** I edit **then** current text changes, original is preserved with edited status; when deleting, actual persisted record is gone after restart.

**US-05:** As a user with a constrained device or poor connectivity, I can still use text capture and find my local notes; no network call is required for the core flow. **Given** offline mode **when** I save and search **then** reliable local results are available subject to OS data protection.

**US-06:** As a cautious user, I can understand what is retained and turn analytics off. **Given** first save **when** disclosure appears **then** it is concise, accurate and separate from any optional instrumentation permission.

## Data model (conceptual, verify against the repo)
`MemoryItem {{ id: UUID, rawText: String, text: String, createdAt?: Date, updatedAt?: Date, source: enum, edited: Bool }}`. Add explicit storage schema version and tombstone/migration markers before production; no new person graph or embedding store required. Query result `RecallResult {{ query, status: found|ambiguous|miss|unsupported_constraint, candidateIDs: [UUID], reasonCode }}`. Do not use model-generated confidence as a probability.

## State transitions and invariants
`DRAFT → VALIDATED → WRITE_PENDING → SAVED | FAILED`. Only `SAVED` shows completion. `SEARCHING → MATCHES | MISS | NEEDS_DETAIL | FAILURE`. Never cross from model text to native action without validated typed arguments and explicit user authorisation. A model may select candidate IDs from a supplied bounded set, but may not invent IDs or mutate notes without a clear user request.

## Non-functional quality gates (engineering targets, not achieved performance)
- **P0 local save:** target p95 ≤ 300 ms on test devices for ordinary notes; display committed state only after durable acknowledgment. Measure slower-device tail.
- **Local exact search:** target p95 ≤ 500 ms for <= 2,000 notes on supported devices; test memory pressure and diacritics.
- **Crash integrity:** zero lost acknowledged records in restart/kill/storage test suite. Any confirmed acknowledged loss blocks release.
- **Wrong confident personal fact:** zero in labelled high-risk regression suite; in user studies report per-denominator error rather than broad guarantees.
- **Availability:** local text search works offline; voice services optional and must report unsupported language/permission states.
- **Accessibility:** no motion or spoken output required to finish the task.

## Analytics event contract
Use a predefined event schema with `event_name, anonymous_trial_id, session_id, timestamp, build_version, onboarding_or_organic, duration_bucket, outcome_code`; prohibit transcripts, note content, names, URLs, message body, precise geolocation or arbitrary diagnostic text. Events: `first_save_attempted`, `save_persisted`, `save_failed`, `organic_recall_attempted`, `recall_correct_confirmed`, `recall_wrong_confirmed`, `recall_uncertain`, `edit_saved`, `delete_confirmed`, `quick_access_invoked`, `reminder_action_verified` (P1). Publish event definitions before testing.

## Explicit permissions and ethics
Core P0 requires no microphone, contacts, calendar or notification permission. Local data storage must have a tested file-protection and backup policy. Users should inspect, correct, export and delete active records. Age-gate validation participants 18+ until youth-specific safety and legal review. GDPR lawful basis, privacy notice, retention and processor review are release requirements [S17].

## Definition of done
A participant can independently save a real note, force-close/restart, retrieve original text, identify ambiguous results, correct/delete/export notes, work offline, decline all optional permissions, and receive true errors when storage is unavailable. Tests run on actual iPhones; code presence or simulation does not satisfy this gate.
