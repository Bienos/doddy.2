# G — Validation Programme and Decision Gates
**Goal:** decide whether Doddy solves a real recurring job better than alternatives. Tests are NOT claimed executed. Suggested total programme: discovery (2 weeks), controlled tasks (1 week), organic-use pilot (28 days), then pricing exploration if gates pass.

## Research arms and samples

| Stage | Proposed sample | Method | Critical decision |
|---|---|---|---|
| 1 Problem interviews | 15–20 adults, screened by a last-14-days example | 30–45min jobs interviews; no pitch for first half | Is failed retrieval frequent/painful enough? |
| 2 Concept test | 40–60 mixed fan/nonfan respondents | Randomised one-job propositions + comprehension | Is capture/recall understood and credible? |
| 3 Comparator usability | 12–16 participants, within-subject cross-over | Same 5 authentic retrieval tasks in Notes/Siri/ChatGPT and Doddy, counterbalanced | Faster and more accurate at comparable effort? |
| 4 Naturalistic pilot | 24–40 qualified adult iPhone users | 28-day TestFlight, no prompted daily engagement | Is there spontaneous save→recall, substitution, repeat? |
| 5 Price test | only users who achieved repeat utility | Offer actual terms / optional paid beta if operationally ready | Any revealed willingness to pay? |

These samples yield directional qualitative signals, not reliable population conversion rates. Use binomial confidence intervals for proportions and explicitly state uncertainty. Randomisation balances order, not demographics or product enthusiasm.

## Screener — must establish past behaviour
Ask for a non-sensitive recent example of saving something you hoped to find later. Where did they put it, when did they need it, how did they search, how long did it take, did they succeed, and why not use Notes/Reminders? Exclude people without a real recent capture habit from the primary cohort; recruit them separately for discoverability testing. Do not demand screenshots of private records.

## Interview protocol (first 12 questions without Doddy pitch)
1. Tell me about the last time you saved a detail for later. 2. Why did it matter? 3. Where did you put it? 4. Show only non-sensitive workflow steps, not private contents. 5. What did you expect to remember? 6. When did you look again? 7. Did you recover it? 8. How much effort did that take? 9. What made the current method good enough? 10. What information would you refuse to put in a new app? 11. What happened the last time a reminder failed? 12. Would a faster retrieval process change anything important? Only then expose unbranded concepts and ask for unaided explanation.

## Five within-subject comparative tasks
1. Save a real-sounding but non-sensitive supplier recommendation and retrieve tomorrow. 2. Retrieve an exact quoted phrase after a misleading similar item is introduced. 3. Find a note after a one-character typo. 4. Find the correct item among two conflicting records. 5. Recover gracefully when requested information was never captured. Counterbalance app order and build comparable starting conditions; do not give Doddy privileged preloaded memory unavailable to comparator.

**Record** task outcome adjudicated correct/wrong/miss, elapsed time from user intent to verified source, taps/utterances, user effort rating, permission friction, confidence calibration, preference reason, and whether character made task better or slower. Report results by app, task, and user.

## Naturalistic 28-day protocol
Day 0: baseline, transparent privacy explanation, sample non-sensitive save and taught recall. Days 1–14: no reminders to open Doddy; log content-free events with separate opt-in; one very short sampled substitution question after at most ~20% of organic successful sessions. Day 14: check-in questions without coaching. Days 15–28: natural behaviour continues; end interview including delete/export exercise. Keep a participant regardless of inactivity. Consent to research is distinct from OS permissions and analytics consent.

## Proposed decision gates: n=24 example

**Continue to deeper beta only when all safety gates and two of three behavioural gates pass:**
- Safety: no acknowledged saved-item loss; no reproduced false action-success; no unresolved severe privacy issue; every confidently wrong personal result investigated and corrected before expansion.
- Behavioural A: >=10/24 (42%) people independently initiate a real recall by day 14, with adjudicated outcomes reported.
- Behavioural B: >=8/24 (33%) people achieve at least **two** organic correct retrievals by day 28 (rather than forced daily opens).
- Behavioural C: >=8/24 report a concrete session where Doddy replaced a tool they normally used, supported by event context, not just “I like Doddy.”

**Hold / repair:** meaningful retrieval attempts exist but accuracy or effort falls short. **Pivot test:** users save frequently but rarely retrieve, while a different spontaneous use appears; validate a different single job separately. **Stop/defer:** users show neither independent recall nor displacement after one focused revision, or critical integrity issues persist. Thresholds are deliberately provisional and should be preregistered before recruitment.

## Specific misleading signals to exclude
Video views, fan enthusiasm, first-day usage, number of chats, synthetic retrieval benchmarks, generic survey enthusiasm, model-demo applause and being on a waitlist do **not** count as organic repeat utility or real payment.

## Rival hypothesis tests
- **Character vs plain utility:** same features, different personality treatment; recruit both fans and cold audience.
- **Text versus voice:** physical-device task tests in home, public, commuting (safe simulation) and low-noise settings; measure permissions and correction cost.
- **Recall vs follow-through:** compare 14-day voluntary recurrence of saved-item lookup against explicitly requested reminder creation; never treat action completion as verified without native confirmation.
- **Doddy vs Siri AI:** include eligible iOS 27 devices and supported Siri AI languages where possible; separately stratify devices without feature availability [S04].

## Decision evidence pack
Deliver CSV with participant IDs pseudonymised, cohort source, dates, attempts, adjudication, alternatives, errors, attrition and missingness; usability screen-recordings only with separate consent and scrubbed sample data. Publish a one-page result per gate with denominators and practical example, plus at least two disconfirming cases.
